"""
GET /pricing/batch/{session_id} — Batch prices for all products.
GET /pricing/{product_id}/{session_id} — Get dynamic price for a product.

NOTE: /batch/ route MUST be defined before /{product_id}/ to avoid
FastAPI treating 'batch' as a product_id wildcard match.
"""
from fastapi import APIRouter, HTTPException
from services import behavior_engine, persona_classifier, pricing_engine
from models.product import DynamicPrice
from models.session import PersonaType

router = APIRouter(prefix="/pricing", tags=["Pricing"])


# ── IMPORTANT: batch route before wildcard ────────────────────────
@router.get("/batch/{session_id}")
async def get_all_prices(session_id: str):
    """Return dynamic prices for every product in the catalog."""
    # Reload product cache on each batch request so data stays fresh
    pricing_engine.invalidate_cache()
    features = behavior_engine.get_features(session_id)
    persona = persona_classifier.classify_persona(features)
    prices = pricing_engine.get_all_prices(
        persona=persona.persona,
        engagement_score=features.engagement_score,
        purchase_intent=features.purchase_intent,
        session_id=session_id,
    )
    return {"prices": [p.model_dump() for p in prices if p]}


@router.get("/{product_id}/{session_id}", response_model=DynamicPrice)
async def get_price(product_id: str, session_id: str):
    """Return dynamic price for a single product."""
    features = behavior_engine.get_features(session_id)
    persona = persona_classifier.classify_persona(features)

    price = pricing_engine.calculate_price(
        product_id=product_id,
        persona=persona.persona,
        engagement_score=features.engagement_score,
        purchase_intent=features.purchase_intent,
        session_id=session_id,
    )
    if not price:
        raise HTTPException(status_code=404, detail=f"Product '{product_id}' not found")
    return price
