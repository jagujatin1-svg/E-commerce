"""
GET /recommendations/{session_id} — Personalized recommendations.
GET /recommendations/trending — Global trending products.
GET /recommendations/deals — Low-inventory deal items.
"""
import json
import os
from fastapi import APIRouter
from services import behavior_engine, persona_classifier, recommendation

router = APIRouter(prefix="/recommendations", tags=["Recommendations"])

_PRODUCTS_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "products.json")


@router.get("/trending")
async def get_trending():
    return {"products": recommendation.get_trending(10)}


@router.get("/deals")
async def get_deals():
    return {"products": recommendation.get_deals(8)}


@router.get("/all")
async def get_all_products():
    with open(_PRODUCTS_PATH) as f:
        products = json.load(f)
    return {"products": products}


@router.get("/{session_id}")
async def get_recommendations(session_id: str, limit: int = 8):
    features = behavior_engine.get_features(session_id)
    persona = persona_classifier.classify_persona(features)

    recs = recommendation.get_recommendations(
        session_id=session_id,
        persona=persona.persona,
        viewed_products=features.viewed_products,
        category_affinities=features.category_affinities,
        limit=limit,
    )
    return {
        "session_id": session_id,
        "persona": persona.persona.value,
        "ui_mode": persona.ui_mode,
        "products": recs,
    }
