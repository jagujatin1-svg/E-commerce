"""
GET /persona/{session_id} — Get current Shadow Persona for a session.
"""
from fastapi import APIRouter, HTTPException
from services import behavior_engine, persona_classifier
from models.session import ShadowPersona

router = APIRouter(prefix="/persona", tags=["Persona"])


@router.get("/{session_id}", response_model=ShadowPersona)
async def get_persona(session_id: str):
    features = behavior_engine.get_features(session_id)
    if features.total_events == 0:
        raise HTTPException(status_code=404, detail="No session data found")
    persona = persona_classifier.classify_persona(features)
    return persona
