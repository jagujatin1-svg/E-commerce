"""
POST /events — Ingest a behavioral event, update session features,
reclassify persona, push real-time WebSocket update.
"""
from fastapi import APIRouter
from models.events import BehaviorEvent, SessionFeatures
from services import behavior_engine, persona_classifier
from websocket.manager import manager

router = APIRouter(prefix="/events", tags=["Events"])


@router.post("", response_model=dict)
async def ingest_event(event: BehaviorEvent):
    # 1. Update session features
    features: SessionFeatures = behavior_engine.ingest_event(event)

    # 2. Reclassify persona
    persona = persona_classifier.classify_persona(features)

    # 3. Push real-time update via WebSocket
    ws_payload = {
        "type": "persona_update",
        "session_id": event.session_id,
        "persona": persona.persona.value,
        "confidence": persona.confidence,
        "scores": persona.scores,
        "signals": persona.signals,
        "ui_mode": persona.ui_mode,
        "features": {
            "total_events": features.total_events,
            "engagement_score": features.engagement_score,
            "purchase_intent": features.purchase_intent,
            "avg_hover_duration": features.avg_hover_duration,
            "events_per_minute": features.events_per_minute,
        },
    }
    await manager.send_to_session(event.session_id, ws_payload)

    return {
        "status": "ok",
        "session_id": event.session_id,
        "total_events": features.total_events,
        "persona": persona.persona.value,
        "confidence": persona.confidence,
    }
