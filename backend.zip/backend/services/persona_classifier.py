"""
Shadow Persona Classifier
Classifies user into: Skimmer | Researcher | Hunter | Unknown
Uses weighted rule-based scoring on behavioral features.
Each persona has distinct signal patterns:
  - Skimmer:    fast scroll, many short clicks, low hover time, high EPM
  - Researcher: long hover, slow scroll, many page views, reads specs
  - Hunter:     cart adds, price comparisons, searches, purchase intent
"""
import time
from models.events import SessionFeatures
from models.session import ShadowPersona, PersonaType

# Minimum events before we commit to a persona
MIN_EVENTS_FOR_CLASSIFICATION = 5


def classify_persona(features: SessionFeatures) -> ShadowPersona:
    scores = {"skimmer": 0.0, "researcher": 0.0, "hunter": 0.0}
    signals = []

    # ── Skimmer signals ──────────────────────────────────────────
    # High events-per-minute → fast, impatient browsing
    if features.events_per_minute > 8:
        scores["skimmer"] += 0.30
        signals.append("⚡ High browsing speed detected")
    elif features.events_per_minute > 5:
        scores["skimmer"] += 0.15

    # Low hover duration → not reading details
    if 0 < features.avg_hover_duration < 800:
        scores["skimmer"] += 0.25
        signals.append("👁️ Short hover time — scanning content")
    elif features.avg_hover_duration == 0 and features.hover_events == 0:
        scores["skimmer"] += 0.10

    # High click-to-page-view ratio → clicking without reading
    if features.page_views > 0:
        click_ratio = features.clicks / features.page_views
        if click_ratio > 2.5:
            scores["skimmer"] += 0.20
            signals.append("🖱️ High click-to-view ratio")
        elif click_ratio > 1.5:
            scores["skimmer"] += 0.10

    # Many scroll events with few page views → fast scrolling
    if features.scroll_events > features.page_views * 1.5:
        scores["skimmer"] += 0.15

    # Lots of distinct products viewed quickly
    if len(features.viewed_products) > 6 and features.session_duration < 120:
        scores["skimmer"] += 0.20
        signals.append("📦 Browsed many products quickly")

    # ── Researcher signals ───────────────────────────────────────
    # Long hover time → reading product details
    if features.avg_hover_duration > 3000:
        scores["researcher"] += 0.35
        signals.append("🔬 Long hover — reading specs carefully")
    elif features.avg_hover_duration > 1500:
        scores["researcher"] += 0.18

    # Slow events-per-minute → methodical browsing
    if 0 < features.events_per_minute < 3:
        scores["researcher"] += 0.25
        signals.append("📖 Slow, deliberate browsing pace")
    elif features.events_per_minute < 5:
        scores["researcher"] += 0.12

    # Multiple page views of same product (revisits)
    if features.page_views > len(features.viewed_products) * 1.5 and features.page_views > 3:
        scores["researcher"] += 0.20
        signals.append("🔄 Revisiting product pages — comparing options")

    # Long session with moderate activity
    if features.session_duration > 180 and features.total_events < 30:
        scores["researcher"] += 0.20
        signals.append("⏱️ Long session — thorough consideration")

    # ── Hunter signals ───────────────────────────────────────────
    # Cart interactions → intent to buy
    if features.cart_actions >= 2:
        scores["hunter"] += 0.35
        signals.append("🛒 Multiple cart interactions")
    elif features.cart_actions == 1:
        scores["hunter"] += 0.20
        signals.append("🛒 Added item to cart")

    # Searches → actively looking for deals
    if features.searches >= 3:
        scores["hunter"] += 0.25
        signals.append("🔍 Repeated searches — looking for best deal")
    elif features.searches >= 1:
        scores["hunter"] += 0.12

    # High purchase intent score
    if features.purchase_intent > 0.7:
        scores["hunter"] += 0.30
        signals.append("💰 High purchase intent detected")
    elif features.purchase_intent > 0.4:
        scores["hunter"] += 0.15

    # High engagement with specific category
    if features.category_affinities:
        top_affinity = max(features.category_affinities.values())
        if top_affinity > 0.6:
            scores["hunter"] += 0.15
            signals.append("🎯 Focused on specific category")

    # ── Normalize scores ─────────────────────────────────────────
    total = sum(scores.values()) or 1.0
    normalized = {k: round(v / total, 3) for k, v in scores.items()}

    # ── Determine winner ─────────────────────────────────────────
    if features.total_events < MIN_EVENTS_FOR_CLASSIFICATION:
        persona = PersonaType.unknown
        confidence = 0.0
        ui_mode = "default"
    else:
        top_persona = max(normalized, key=normalized.get)
        confidence = normalized[top_persona]
        persona = PersonaType(top_persona)

        # Require at least 35% confidence to commit
        if confidence < 0.35:
            persona = PersonaType.unknown
            ui_mode = "default"
        else:
            ui_mode = {
                "skimmer": "trending",
                "researcher": "detailed",
                "hunter": "deals",
            }[top_persona]

    # Filter signals to top 3 most relevant
    signals = signals[:3] if signals else ["👋 Building your profile..."]

    return ShadowPersona(
        session_id=features.session_id,
        persona=persona,
        confidence=round(confidence, 3),
        scores=normalized,
        signals=signals,
        ui_mode=ui_mode,
        detected_at=time.time(),
    )
