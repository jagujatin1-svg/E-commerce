"""
Behavior Engine — extracts real-time features from raw behavioral events.
Computes engagement score, purchase intent, scroll/hover patterns,
category affinities, and events-per-minute.
"""
import time
from collections import defaultdict
from typing import List
from models.events import BehaviorEvent, SessionFeatures

# In-memory session store (replaces DB for real-time speed)
_sessions: dict[str, dict] = {}


def _get_or_create_session(session_id: str) -> dict:
    if session_id not in _sessions:
        _sessions[session_id] = {
            "session_id": session_id,
            "events": [],
            "start_time": time.time(),
            "total_events": 0,
            "page_views": 0,
            "clicks": 0,
            "hover_events": 0,
            "scroll_events": 0,
            "cart_actions": 0,
            "searches": 0,
            "hover_durations": [],
            "scroll_speeds": [],
            "category_counts": defaultdict(int),
            "viewed_products": [],
            "last_event_time": time.time(),
        }
    return _sessions[session_id]


def ingest_event(event: BehaviorEvent) -> SessionFeatures:
    """Process a new behavioral event and update session features."""
    s = _get_or_create_session(event.session_id)

    s["events"].append(event)
    s["total_events"] += 1
    s["last_event_time"] = event.timestamp

    # --- Counters ---
    et = event.event_type.value
    if et == "page_view":
        s["page_views"] += 1
        if event.product_id and event.product_id not in s["viewed_products"]:
            s["viewed_products"].append(event.product_id)
    elif et == "click":
        s["clicks"] += 1
    elif et == "hover":
        s["hover_events"] += 1
        dur = event.metadata.get("duration_ms", 0)
        if dur > 0:
            s["hover_durations"].append(dur)
    elif et == "scroll":
        s["scroll_events"] += 1
        speed = event.metadata.get("speed", 0)
        if speed > 0:
            s["scroll_speeds"].append(speed)
    elif et in ("cart_add", "cart_remove", "purchase"):
        s["cart_actions"] += 1
    elif et == "search":
        s["searches"] += 1

    # --- Category affinity ---
    if event.category:
        s["category_counts"][event.category] += 1

    return _compute_features(s)


def _compute_features(s: dict) -> SessionFeatures:
    now = time.time()
    session_duration = now - s["start_time"]
    epm = (s["total_events"] / max(session_duration / 60, 0.1))

    avg_hover = (
        sum(s["hover_durations"]) / len(s["hover_durations"])
        if s["hover_durations"] else 0.0
    )
    avg_scroll = (
        sum(s["scroll_speeds"]) / len(s["scroll_speeds"])
        if s["scroll_speeds"] else 0.0
    )

    # --- Engagement score (0-1) ---
    # Weighted sum of normalized signals
    engagement = min(1.0, (
        (s["clicks"] * 0.25) +
        (s["hover_events"] * 0.15) +
        (s["page_views"] * 0.20) +
        (s["cart_actions"] * 0.30) +
        (s["searches"] * 0.10)
    ) / max(s["total_events"], 1))

    # Boost engagement for cart and search activity
    engagement = min(1.0, engagement + s["cart_actions"] * 0.08 + s["searches"] * 0.05)

    # --- Purchase intent (0-1) ---
    intent_signals = [
        s["cart_actions"] * 0.40,
        s["searches"] * 0.20,
        min(s["page_views"] / 10, 1.0) * 0.20,
        min(avg_hover / 5000, 1.0) * 0.20,
    ]
    purchase_intent = min(1.0, sum(intent_signals))

    # --- Category affinities ---
    total_cat = sum(s["category_counts"].values()) or 1
    affinities = {k: round(v / total_cat, 3) for k, v in s["category_counts"].items()}

    return SessionFeatures(
        session_id=s["session_id"],
        total_events=s["total_events"],
        page_views=s["page_views"],
        clicks=s["clicks"],
        hover_events=s["hover_events"],
        scroll_events=s["scroll_events"],
        cart_actions=s["cart_actions"],
        searches=s["searches"],
        avg_hover_duration=round(avg_hover, 2),
        avg_scroll_speed=round(avg_scroll, 2),
        engagement_score=round(engagement, 3),
        category_affinities=affinities,
        viewed_products=s["viewed_products"],
        session_duration=round(session_duration, 2),
        events_per_minute=round(epm, 2),
        purchase_intent=round(purchase_intent, 3),
    )


def get_features(session_id: str) -> SessionFeatures:
    """Retrieve current session features without adding a new event."""
    if session_id not in _sessions:
        return SessionFeatures(session_id=session_id)
    return _compute_features(_sessions[session_id])


def get_raw_session(session_id: str) -> dict:
    return _sessions.get(session_id, {})


def all_session_ids() -> list:
    return list(_sessions.keys())
