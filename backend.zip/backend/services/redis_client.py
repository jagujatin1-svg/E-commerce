"""
Redis client with in-memory fallback for environments without Redis.
Provides the same interface so services work seamlessly.
"""
import json
import time
from typing import Optional, Any

try:
    import redis.asyncio as aioredis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

# In-memory store fallback
_store: dict = {}
_expiry: dict = {}


class MemoryRedis:
    """Pure in-memory Redis-compatible client."""

    async def set(self, key: str, value: str, ex: Optional[int] = None):
        _store[key] = value
        if ex:
            _expiry[key] = time.time() + ex

    async def get(self, key: str) -> Optional[str]:
        if key in _expiry and time.time() > _expiry[key]:
            del _store[key]
            del _expiry[key]
            return None
        return _store.get(key)

    async def delete(self, key: str):
        _store.pop(key, None)
        _expiry.pop(key, None)

    async def exists(self, key: str) -> bool:
        return key in _store

    async def incr(self, key: str) -> int:
        val = int(_store.get(key, 0)) + 1
        _store[key] = str(val)
        return val

    async def expire(self, key: str, seconds: int):
        _expiry[key] = time.time() + seconds

    async def publish(self, channel: str, message: str):
        pass  # no-op in memory mode

    async def ping(self):
        return True


_redis_client: Optional[Any] = None


async def get_redis():
    global _redis_client
    if _redis_client is None:
        if REDIS_AVAILABLE:
            try:
                client = aioredis.from_url("redis://localhost:6379", decode_responses=True)
                await client.ping()
                _redis_client = client
                print("✅ Connected to Redis")
            except Exception:
                print("⚠️  Redis not available, using in-memory store")
                _redis_client = MemoryRedis()
        else:
            _redis_client = MemoryRedis()
    return _redis_client


async def cache_set(key: str, data: Any, ttl: int = 300):
    r = await get_redis()
    await r.set(key, json.dumps(data), ex=ttl)


async def cache_get(key: str) -> Optional[Any]:
    r = await get_redis()
    raw = await r.get(key)
    if raw:
        return json.loads(raw)
    return None


async def cache_delete(key: str):
    r = await get_redis()
    await r.delete(key)
