"""
Dynamic Pricing Engine
Computes personalized real-time prices using:
  - Base product price
  - Demand velocity multiplier
  - Inventory scarcity factor
  - Shadow Persona modifier
  - Engagement-based urgency
All changes are explainable (reasons list returned to frontend).
"""
import json
import os
from typing import Optional
from models.product import DynamicPrice
from models.session import PersonaType

# Load product catalog
_PRODUCTS_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "products.json")
_products_cache: dict = {}


def _load_products() -> dict:
    global _products_cache
    if not _products_cache:
        with open(_PRODUCTS_PATH, "r") as f:
            products = json.load(f)
        _products_cache = {p["id"]: p for p in products}
    return _products_cache


def invalidate_cache():
    """Force reload of products.json on next access."""
    global _products_cache
    _products_cache = {}


def calculate_price(
    product_id: str,
    persona: PersonaType,
    engagement_score: float,
    purchase_intent: float,
    session_id: str = "anonymous",
) -> Optional[DynamicPrice]:
    products = _load_products()
    product = products.get(product_id)
    if not product:
        return None

    base_price = product["base_price"]
    inventory = product["inventory"]
    demand_score = product["demand_score"]

    reasons = []
    persona_modifier = 1.0
    demand_modifier = 1.0
    inventory_modifier = 1.0

    # ── Persona Modifier ─────────────────────────────────────────
    if persona == PersonaType.skimmer:
        # Slight discount — trigger impulse purchase
        persona_modifier = 0.98
        reasons.append("⚡ Flash deal for fast browsers (-2%)")
    elif persona == PersonaType.researcher:
        # Neutral — researchers are quality-focused, not price-driven
        persona_modifier = 1.00
        reasons.append("🔬 Standard pricing — quality guaranteed")
    elif persona == PersonaType.hunter:
        # Meaningful discount — they're looking for deals
        if purchase_intent > 0.6:
            persona_modifier = 0.93
            reasons.append("🎯 Exclusive deal unlocked (-7%)")
        else:
            persona_modifier = 0.96
            reasons.append("🛒 Deal finder discount (-4%)")
    else:
        persona_modifier = 1.00

    # ── Demand Modifier ──────────────────────────────────────────
    if demand_score > 0.90:
        demand_modifier = 1.05
        reasons.append("🔥 Extremely high demand (+5%)")
    elif demand_score > 0.80:
        demand_modifier = 1.03
        reasons.append("📈 High demand (+3%)")
    elif demand_score > 0.70:
        demand_modifier = 1.01
    # Low demand → no extra charge (keep pricing fair)

    # Engagement boost — actively interested user, still fair
    if engagement_score > 0.75 and demand_score > 0.80:
        demand_modifier = min(demand_modifier + 0.01, 1.08)
        reasons.append("⚡ You're viewing a trending item")

    # ── Inventory Modifier ───────────────────────────────────────
    if inventory <= 3:
        inventory_modifier = 1.04
        reasons.append(f"⚠️ Only {inventory} left in stock! (+4%)")
    elif inventory <= 8:
        inventory_modifier = 1.02
        reasons.append(f"📦 Low stock — {inventory} remaining (+2%)")
    elif inventory <= 15:
        inventory_modifier = 1.01
        reasons.append(f"📦 Limited availability — {inventory} left")

    # ── Final Price ──────────────────────────────────────────────
    multiplier = persona_modifier * demand_modifier * inventory_modifier
    final_price = round(base_price * multiplier, 2)
    discount_pct = round((1 - multiplier) * 100, 2)

    # Ethical cap: never raise price > 10% or drop > 12%
    max_price = base_price * 1.10
    min_price = base_price * 0.88
    final_price = round(max(min_price, min(final_price, max_price)), 2)
    multiplier = round(final_price / base_price, 4)
    discount_pct = round((1 - multiplier) * 100, 2)

    if not reasons:
        reasons.append("✅ Standard market price")

    return DynamicPrice(
        product_id=product_id,
        session_id=session_id,
        base_price=base_price,
        final_price=final_price,
        discount_pct=discount_pct,
        multiplier=multiplier,
        reasons=reasons,
        persona_modifier=round(persona_modifier, 4),
        demand_modifier=round(demand_modifier, 4),
        inventory_modifier=round(inventory_modifier, 4),
    )


def get_all_prices(
    persona: PersonaType,
    engagement_score: float,
    purchase_intent: float,
    session_id: str,
) -> list:
    products = _load_products()
    return [
        calculate_price(pid, persona, engagement_score, purchase_intent, session_id)
        for pid in products
    ]
