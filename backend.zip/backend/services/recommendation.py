"""
Recommendation Engine
Combines:
  1. Category-affinity filtering — surface products in preferred categories
  2. Session-based collaborative filtering — "others also viewed"
  3. Persona-specific curations:
       Skimmer   → trending / high-demand items
       Researcher → top-rated, detail-rich products
       Hunter    → best value / low inventory deals
"""
import json
import os
import random
from typing import List, Optional
from models.session import PersonaType

_PRODUCTS_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "products.json")
_products_cache: list = []


def _load_products() -> list:
    global _products_cache
    if not _products_cache:
        with open(_PRODUCTS_PATH, "r") as f:
            _products_cache = json.load(f)
    return _products_cache


def invalidate_cache():
    global _products_cache
    _products_cache = []


# Load on import
_load_products()


def get_recommendations(
    session_id: str,
    persona: PersonaType,
    viewed_products: List[str],
    category_affinities: dict,
    limit: int = 8,
) -> List[dict]:
    products = _load_products()

    # Exclude already-viewed products
    unseen = [p for p in products if p["id"] not in viewed_products]

    scored: list[tuple[float, dict]] = []

    for product in unseen:
        score = 0.0

        # ── Category affinity boost ──────────────────────────────
        cat_score = category_affinities.get(product["category"], 0.0)
        score += cat_score * 40.0

        # ── Persona-specific scoring ─────────────────────────────
        if persona == PersonaType.skimmer:
            # Trending, popular items
            score += product["demand_score"] * 35.0
            score += min(product["reviews"] / 1000, 1.0) * 15.0
            score += product["rating"] * 5.0

        elif persona == PersonaType.researcher:
            # High-rated, well-reviewed, detail-rich
            score += product["rating"] * 15.0
            score += min(product["reviews"] / 10000, 1.0) * 20.0
            spec_richness = len(product.get("specs", {}))
            score += spec_richness * 5.0
            # Prefer items with longer descriptions
            score += len(product.get("tags", [])) * 2.0

        elif persona == PersonaType.hunter:
            # Best value — high demand but lower inventory (deal potential)
            score += product["demand_score"] * 20.0
            # Low-inventory items feel like deals
            if product["inventory"] < 20:
                score += 25.0
            if product["inventory"] < 8:
                score += 15.0
            # High reviews = trusted deal
            score += min(product["reviews"] / 5000, 1.0) * 20.0

        else:
            # Unknown persona → balanced, popularity-based
            score += product["demand_score"] * 25.0
            score += product["rating"] * 10.0

        # ── Small random factor to prevent identical lists ────────
        score += random.uniform(0, 3.0)

        scored.append((score, product))

    # Sort descending by score
    scored.sort(key=lambda x: x[0], reverse=True)

    result = [p for _, p in scored[:limit]]

    # If we don't have enough unseen items, pad with popular ones
    if len(result) < limit:
        seen_ids = {p["id"] for p in result}
        fallback = sorted(products, key=lambda x: x["demand_score"], reverse=True)
        for p in fallback:
            if p["id"] not in seen_ids and len(result) < limit:
                result.append(p)

    return result


def get_trending(limit: int = 10) -> List[dict]:
    """Returns globally trending products regardless of persona."""
    products = _load_products()
    return sorted(products, key=lambda x: x["demand_score"], reverse=True)[:limit]


def get_deals(limit: int = 8) -> List[dict]:
    """Returns low-inventory, high-demand items — deal framing."""
    products = _load_products()
    scored = [(p["demand_score"] * (1 / max(p["inventory"] / 100, 0.05)), p) for p in products]
    scored.sort(reverse=True)
    return [p for _, p in scored[:limit]]
