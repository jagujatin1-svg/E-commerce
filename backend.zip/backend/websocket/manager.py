"""
WebSocket Connection Manager
Manages per-session WebSocket connections.
Broadcasts real-time persona + pricing updates to connected clients.
"""
import asyncio
import json
from typing import Dict
from fastapi import WebSocket


class ConnectionManager:
    def __init__(self):
        # session_id -> WebSocket
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, session_id: str):
        await websocket.accept()
        self.active_connections[session_id] = websocket
        print(f"🔌 WS connected: {session_id} ({len(self.active_connections)} total)")

    def disconnect(self, session_id: str):
        self.active_connections.pop(session_id, None)
        print(f"🔌 WS disconnected: {session_id}")

    async def send_to_session(self, session_id: str, data: dict):
        ws = self.active_connections.get(session_id)
        if ws:
            try:
                await ws.send_text(json.dumps(data))
            except Exception:
                self.disconnect(session_id)

    async def broadcast(self, data: dict):
        dead = []
        for sid, ws in self.active_connections.items():
            try:
                await ws.send_text(json.dumps(data))
            except Exception:
                dead.append(sid)
        for sid in dead:
            self.disconnect(sid)

    def connection_count(self) -> int:
        return len(self.active_connections)


# Singleton instance
manager = ConnectionManager()
