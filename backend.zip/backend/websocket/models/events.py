from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum
import time

class EventType(str, Enum):
    page_view = "page_view"
    click = "click"
    hover = "hover"
    scroll = "scroll"
    search = "search"
    cart_add = "cart_add"
    cart_remove = "cart_remove"
    purchase = "purchase"
    compare = "compare"
    wishlist = "wishlist"

class BehaviorEvent(BaseModel):
    session_id: str
    event_type: EventType
    product_id: Optional[str] = None
    category: Optional[str] = None
    timestamp: float = Field(default_factory=lambda: time.time())
    metadata: Optional[dict] = {}

class SessionFeatures(BaseModel):
    session_id: str
    total_events: int = 0
    page_views: int = 0
    clicks: int = 0
    hover_events: int = 0
    scroll_events: int = 0
    cart_actions: int = 0
    searches: int = 0
    avg_hover_duration: float = 0.0
    avg_scroll_speed: float = 0.0
    engagement_score: float = 0.0
    category_affinities: dict = {}
    viewed_products: List[str] = []
    session_duration: float = 0.0
    events_per_minute: float = 0.0
    purchase_intent: float = 0.0
