from pydantic import BaseModel
from typing import List, Optional, Dict

class ProductSpec(BaseModel):
    key: str
    value: str

class Product(BaseModel):
    id: str
    name: str
    category: str
    subcategory: str
    base_price: float
    inventory: int
    rating: float
    reviews: int
    image: str
    tags: List[str]
    specs: Dict[str, str]
    demand_score: float

class DynamicPrice(BaseModel):
    product_id: str
    session_id: str
    base_price: float
    final_price: float
    discount_pct: float
    multiplier: float
    reasons: List[str]
    persona_modifier: float
    demand_modifier: float
    inventory_modifier: float
