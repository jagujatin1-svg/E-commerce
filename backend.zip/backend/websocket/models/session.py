from pydantic import BaseModel
from typing import Optional
from enum import Enum

class PersonaType(str, Enum):
    skimmer = "skimmer"
    researcher = "researcher"
    hunter = "hunter"
    unknown = "unknown"

class ShadowPersona(BaseModel):
    session_id: str
    persona: PersonaType
    confidence: float
    scores: dict        # {skimmer: 0.x, researcher: 0.x, hunter: 0.x}
    signals: list       # Readable explanations
    ui_mode: str        # e.g. "trending", "detailed", "deals"
    detected_at: float
