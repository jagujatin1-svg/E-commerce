"""
FastAPI Entrypoint — Real-Time E-Commerce Dynamic Pricing Engine
────────────────────────────────────────────────────────────────
Endpoints:
  POST /events                     — Ingest behavioral event
  GET  /persona/{session_id}       — Get Shadow Persona
  GET  /pricing/{pid}/{session_id} — Get dynamic price
  GET  /pricing/batch/{session_id} — Batch prices
  GET  /recommendations/{session_id}
  GET  /recommendations/trending
  GET  /recommendations/deals
  GET  /products                   — Full catalog
  WS   /ws/{session_id}            — Real-time stream
  GET  /health                     — Health check
"""
import sys, os

# Ensure the backend root is in sys.path
sys.path.insert(0, os.path.dirname(__file__))

import json
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

from routers import events, persona, pricing, recommendations
from websocket.manager import manager
from services import behavior_engine, persona_classifier

# ── Seed product JSON on startup ──────────────────────────────
_DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
_PRODUCT_FILE = os.path.join(_DATA_DIR, "products.json")


def _ensure_products():
    if not os.path.exists(_PRODUCT_FILE):
        os.makedirs(_DATA_DIR, exist_ok=True)
        # Run seed script
        seed_path = os.path.join(_DATA_DIR, "seed.py")
        old_cwd = os.getcwd()
        os.chdir(_DATA_DIR)
        exec(open(seed_path).read())
        os.chdir(old_cwd)


@asynccontextmanager
async def lifespan(app: FastAPI):
    _ensure_products()
    print("🚀 E-Commerce Pricing Engine started")
    yield
    print("🔴 Shutting down")


app = FastAPI(
    title="Real-Time Dynamic Pricing & Personalization Engine",
    description="Shadow Persona detection + dynamic pricing + personalized recommendations",
    version="1.0.0",
    lifespan=lifespan,
)

# ── CORS ──────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────
app.include_router(events.router)
app.include_router(persona.router)
app.include_router(pricing.router)
app.include_router(recommendations.router)


# ── Products catalog endpoint ─────────────────────────────────
@app.get("/products", tags=["Products"])
async def get_products():
    with open(_PRODUCT_FILE) as f:
        return {"products": json.load(f)}


@app.get("/products/{product_id}", tags=["Products"])
async def get_product(product_id: str):
    with open(_PRODUCT_FILE) as f:
        products = json.load(f)
    for p in products:
        if p["id"] == product_id:
            return p
    from fastapi import HTTPException
    raise HTTPException(status_code=404, detail="Product not found")


# ── Health ────────────────────────────────────────────────────
@app.get("/health", tags=["System"])
async def health():
    return {
        "status": "healthy",
        "ws_connections": manager.connection_count(),
        "active_sessions": len(behavior_engine.all_session_ids()),
    }


# ── WebSocket real-time stream ────────────────────────────────
@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    await manager.connect(websocket, session_id)
    try:
        # Send initial state
        features = behavior_engine.get_features(session_id)
        persona = persona_classifier.classify_persona(features)
        await manager.send_to_session(session_id, {
            "type": "connected",
            "session_id": session_id,
            "persona": persona.persona.value,
            "confidence": persona.confidence,
            "message": "Real-time pricing engine connected ⚡",
        })

        while True:
            # Keep connection alive — events pushed from /events route
            data = await websocket.receive_text()
            # Client can optionally send ping
            if data == "ping":
                await manager.send_to_session(session_id, {"type": "pong"})

    except WebSocketDisconnect:
        manager.disconnect(session_id)
