'use client';

import Link from 'next/link';
import { usePersonaStore, DynamicPrice } from '@/store/personaStore';
import { Product } from '@/lib/api';
import { Star, ShoppingCart, TrendingUp, Package, Check, Heart } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  dynamicPrice?: DynamicPrice | null;
  compact?: boolean;
}

const CATEGORY_COLORS: Record<string, { bg: string; text: string }> = {
  Electronics:    { bg: '#e8f3ff', text: '#1a56db' },
  'Mobile Phones':{ bg: '#f0f0ff', text: '#4f46e5' },
  Gaming:         { bg: '#fff0f0', text: '#ef4444' },
  Photography:    { bg: '#fff8e8', text: '#d97706' },
  Wearables:      { bg: '#e8fff4', text: '#059669' },
  Accessories:    { bg: '#f5f0ff', text: '#7c3aed' },
  Fashion:        { bg: '#fff0f9', text: '#c026d3' },
  Sports:         { bg: '#fff4ec', text: '#f97316' },
  Home:           { bg: '#f0fdf4', text: '#16a34a' },
  Beauty:         { bg: '#fdf2f8', text: '#e11d48' },
};

export default function ProductCard({ product, dynamicPrice, compact = false }: ProductCardProps) {
  const { addToCart, cartItems, toggleWishlist, isWishlisted, addToast } = usePersonaStore();
  const inCart = cartItems.includes(product.id);
  const wishlisted = isWishlisted(product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!inCart) {
      addToCart(product.id);
      addToast(`${product.name.slice(0, 32)}… added to cart! 🛒`, 'success');
    }
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    toggleWishlist(product.id);
    addToast(wishlisted ? 'Removed from wishlist' : '❤️ Added to wishlist!', wishlisted ? 'info' : 'success');
  };

  const displayPrice = dynamicPrice?.final_price ?? product.base_price;
  const discount = dynamicPrice?.discount_pct ?? 0;
  const hasDiscount = discount > 0.5;
  const catColor = CATEGORY_COLORS[product.category] ?? { bg: '#f5f5f5', text: '#666' };
  const isLowStock = product.inventory < 10;
  const isHot = product.demand_score > 0.85;

  return (
    <div
      className="card"
      style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden', borderRadius: 'var(--r-lg)' }}
      data-product-id={product.id}
    >
      {/* Image */}
      <div
        className="product-img"
        style={{ height: compact ? 130 : 190, flexShrink: 0, position: 'relative', background: catColor.bg }}
      >
        {product.image ? (
          <img
            src={product.image}
            alt={product.name}
            style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.5s ease' }}
            loading="lazy"
            crossOrigin="anonymous"
            referrerPolicy="no-referrer-when-downgrade"
          />
        ) : (
          <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '3rem' }}>
            {getCategoryEmoji(product.category)}
          </div>
        )}

        {/* Top badges */}
        <div style={{ position: 'absolute', top: 8, left: 8, display: 'flex', flexDirection: 'column', gap: 4 }}>
          {hasDiscount && (
            <span className="badge badge-sale">-{Math.round(discount)}%</span>
          )}
          {isLowStock && (
            <span className="badge badge-low">Low Stock</span>
          )}
        </div>
        {isHot && (
          <div style={{
            position: 'absolute', top: 8, right: 8,
            display: 'flex', alignItems: 'center', gap: 3,
          }}>
            <span className="badge badge-hot">
              <TrendingUp size={9} strokeWidth={2.5} />Hot
            </span>
          </div>
        )}

        {/* Wishlist button */}
        <button
          onClick={handleWishlist}
          style={{
            position: 'absolute', bottom: 8, right: 8,
            width: 30, height: 30, borderRadius: '50%',
            background: wishlisted ? 'var(--rose)' : 'rgba(255,255,255,0.85)',
            border: 'none', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
            transition: 'all 0.2s',
            backdropFilter: 'blur(4px)',
          }}
        >
          <Heart size={14} fill={wishlisted ? 'white' : 'none'} color={wishlisted ? 'white' : 'var(--rose)'} strokeWidth={2} />
        </button>
      </div>

      {/* Body */}
      <div style={{ padding: compact ? '0.75rem' : '1rem', display: 'flex', flexDirection: 'column', flex: 1 }}>
        {/* Category label */}
        <span
          className="label"
          style={{ color: catColor.text, marginBottom: 4, display: 'block' }}
        >
          {product.subcategory}
        </span>

        <h3 style={{
          fontSize: compact ? '0.8rem' : '0.9rem', fontWeight: 700,
          color: 'var(--text-primary)', lineHeight: 1.35,
          marginBottom: compact ? 4 : 8,
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
        }}>
          {product.name}
        </h3>

        {!compact && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 8 }}>
            <div style={{ display: 'flex', gap: 1 }}>
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={11} strokeWidth={0}
                  fill={i < Math.round(product.rating) ? '#f59e0b' : '#e2e8f0'}
                />
              ))}
            </div>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
              {product.rating.toFixed(1)} ({product.reviews.toLocaleString('en-IN')})
            </span>
          </div>
        )}

        {/* Price + CTA */}
        <div style={{ marginTop: 'auto', paddingTop: 10, borderTop: '1px solid var(--border-light)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
              <span
                className={dynamicPrice ? 'price-changed' : ''}
                style={{ fontSize: compact ? '1rem' : '1.1rem', fontWeight: 900, color: 'var(--text-primary)' }}
              >
                ₹{Math.round(displayPrice).toLocaleString('en-IN')}
              </span>
              {hasDiscount && (
                <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textDecoration: 'line-through' }}>
                  ₹{product.base_price.toLocaleString('en-IN')}
                </span>
              )}
            </div>
            {dynamicPrice?.reasons?.[0] && (
              <p style={{ fontSize: '0.68rem', color: 'var(--mint)', fontWeight: 600, marginTop: 2 }}>
                {dynamicPrice.reasons[0]}
              </p>
            )}
          </div>

          <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
            <Link href={`/product/${product.id}`} style={{ textDecoration: 'none' }}>
              <button className="btn-ghost" style={{ padding: '0.45rem 0.875rem', fontSize: '0.75rem' }}>
                View
              </button>
            </Link>
            <button
              onClick={handleAddToCart}
              disabled={inCart}
              style={{
                display: 'flex', alignItems: 'center', gap: 4,
                padding: '0.45rem 0.875rem', borderRadius: 'var(--r-full)',
                fontSize: '0.75rem', fontWeight: 700, border: 'none', cursor: inCart ? 'default' : 'pointer',
                background: inCart ? 'var(--mint-bg)' : 'var(--text-primary)',
                color: inCart ? 'var(--mint)' : 'white',
                transition: 'all 0.2s',
              }}
            >
              {inCart ? <><Check size={13} /> Added</> : <><ShoppingCart size={13} /> Add</>}
            </button>
          </div>
        </div>

        {/* Inventory bar */}
        {!compact && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 8 }}>
            <Package size={11} color="var(--text-muted)" />
            <div className="conf-bar" style={{ flex: 1 }}>
              <div
                className="conf-fill"
                style={{
                  width: `${Math.min(100, (product.inventory / 150) * 100)}%`,
                  background: isLowStock ? 'var(--rose)' : product.inventory < 30 ? '#f59e0b' : 'var(--mint)',
                }}
              />
            </div>
            <span style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>{product.inventory} left</span>
          </div>
        )}
      </div>
    </div>
  );
}

function getCategoryEmoji(cat: string) {
  const m: Record<string,string> = { Electronics:'💻', Gaming:'🎮', Photography:'📷', Wearables:'⌚', 'Mobile Phones':'📱', Accessories:'🔌', Home:'🏠', Fashion:'👗', Sports:'🏋️', Beauty:'💄' };
  return m[cat] ?? '📦';
}
