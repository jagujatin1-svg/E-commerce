'use client';

import { useEffect, useState } from 'react';
import { getRecommendations, getTrending, getDeals, Product } from '@/lib/api';
import { usePersonaStore } from '@/store/personaStore';
import ProductCard from './ProductCard';
import { Sparkles, Flame, Tag, ChevronRight } from 'lucide-react';

interface RecommendationRailProps {
  sessionId: string;
  mode?: 'personalized' | 'trending' | 'deals';
  title?: string;
}

export default function RecommendationRail({ sessionId, mode = 'personalized', title }: RecommendationRailProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { priceMap, persona } = usePersonaStore();

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        if (mode === 'personalized') {
          const data = await getRecommendations(sessionId);
          setProducts(data.products ?? []);
        } else if (mode === 'trending') {
          const data = await getTrending();
          setProducts(data.products ?? []);
        } else {
          const data = await getDeals();
          setProducts(data.products ?? []);
        }
      } catch {
        setProducts([]);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [sessionId, mode, persona]);

  const icons = {
    personalized: <Sparkles className="w-4 h-4 text-[#6272f5]" />,
    trending: <Flame className="w-4 h-4 text-orange-400" />,
    deals: <Tag className="w-4 h-4 text-emerald-400" />,
  };

  const defaultTitles = {
    personalized: 'Recommended For You',
    trending: 'Trending Now',
    deals: 'Best Deals',
  };

  const displayTitle = title ?? defaultTitles[mode];

  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {icons[mode]}
          <h2 className="text-white font-bold text-lg">{displayTitle}</h2>
          {mode === 'personalized' && persona !== 'unknown' && (
            <span className="text-xs text-slate-500 ml-1">based on your persona</span>
          )}
        </div>
        <button className="flex items-center gap-1 text-slate-400 hover:text-white text-sm transition-colors">
          See all <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {loading ? (
        <div className="scroll-rail">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="skeleton rounded-2xl flex-shrink-0" style={{ width: '220px', height: '320px' }} />
          ))}
        </div>
      ) : products.length === 0 ? (
        <p className="text-slate-500 text-sm py-8 text-center">No products available</p>
      ) : (
        <div className="scroll-rail pb-3">
          {products.map((p) => (
            <div key={p.id} className="flex-shrink-0" style={{ width: '220px' }}>
              <ProductCard
                product={p}
                dynamicPrice={priceMap[p.id] ?? null}
                compact
              />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
