'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { usePersonaStore } from '@/store/personaStore';
import { ShoppingCart, Sparkles, Heart, Menu, X } from 'lucide-react';
import { useState } from 'react';

const PERSONA_COLORS: Record<string, string> = {
  skimmer:    '#f97316',
  researcher: '#1a56db',
  hunter:     '#2db88a',
  unknown:    '#7a96aa',
};
const PERSONA_LABELS: Record<string, string> = {
  skimmer:    '⚡ Skimmer',
  researcher: '🔬 Researcher',
  hunter:     '🎯 Hunter',
  unknown:    'Learning...',
};

export default function Navbar() {
  const pathname = usePathname();
  const { persona, isConnected: connected, cartItems, wishlistItems } = usePersonaStore();
  const [menuOpen, setMenuOpen] = useState(false);

  const personaColor = PERSONA_COLORS[persona] ?? PERSONA_COLORS.unknown;
  const personaLabel = PERSONA_LABELS[persona] ?? 'Learning...';

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/products', label: 'Products' },
    { href: '/immersive', label: '✦ 3D Mode' },
    { href: '/dashboard', label: 'Dashboard' },
    { href: '/wishlist', label: 'Wishlist' },
  ];

  return (
    <nav className="navbar">
      <div className="max-container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '64px' }}>
        {/* Logo */}
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', textDecoration: 'none' }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10,
            background: 'var(--text-primary)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Sparkles size={18} color="white" strokeWidth={2.5} />
          </div>
          <span style={{ fontWeight: 900, fontSize: '1.1rem', letterSpacing: '-0.02em', color: 'var(--text-primary)' }}>
            Nex<span style={{ color: 'var(--accent)' }}>Shop</span>
          </span>
        </Link>

        {/* Desktop nav links */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }} className="hidden-mobile">
          {navLinks.map(({ href, label }) => (
            <Link
              key={href}
              href={href}
              style={{
                padding: '0.4rem 0.875rem',
                borderRadius: 'var(--r-full)',
                fontSize: '0.875rem',
                fontWeight: 600,
                textDecoration: 'none',
                color: pathname === href ? 'var(--text-primary)' : 'var(--text-secondary)',
                background: pathname === href ? 'var(--surface)' : 'transparent',
                boxShadow: pathname === href ? 'var(--shadow-sm)' : 'none',
                border: pathname === href ? '1px solid var(--border)' : '1px solid transparent',
                transition: 'all 0.15s',
              }}
            >
              {label}
            </Link>
          ))}
        </div>

        {/* Right side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          {/* Live status */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: '0.4rem',
            padding: '0.35rem 0.75rem', borderRadius: 'var(--r-full)',
            background: 'var(--surface)', border: '1px solid var(--border)',
            fontSize: '0.72rem', fontWeight: 700,
            color: connected ? 'var(--mint)' : 'var(--text-muted)',
          }}>
            <span style={{
              width: 6, height: 6, borderRadius: '50%',
              background: connected ? 'var(--mint)' : 'var(--text-muted)',
              boxShadow: connected ? '0 0 6px var(--mint)' : 'none',
            }} />
            {connected ? 'Live AI' : 'Connecting'}
          </div>

          {/* Persona chip */}
          {persona !== 'unknown' && (
            <div style={{
              padding: '0.35rem 0.75rem', borderRadius: 'var(--r-full)',
              background: `${personaColor}15`, border: `1px solid ${personaColor}30`,
              fontSize: '0.72rem', fontWeight: 700, color: personaColor,
            }}>
              {personaLabel}
            </div>
          )}

          {/* Wishlist */}
          <Link href="/wishlist" style={{ position: 'relative', textDecoration: 'none' }}>
            <button style={{
              width: 40, height: 40, borderRadius: 'var(--r-md)',
              background: 'var(--surface)', border: '1.5px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', transition: 'all 0.15s', boxShadow: 'var(--shadow-sm)',
            }}>
              <Heart size={17} color={wishlistItems.length > 0 ? 'var(--rose)' : 'var(--text-primary)'} fill={wishlistItems.length > 0 ? 'var(--rose)' : 'none'} strokeWidth={2} />
              {wishlistItems.length > 0 && (
                <span style={{
                  position: 'absolute', top: -4, right: -4,
                  minWidth: 18, height: 18, borderRadius: '50%',
                  background: 'var(--rose)', color: 'white',
                  fontSize: '0.65rem', fontWeight: 800,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {wishlistItems.length}
                </span>
              )}
            </button>
          </Link>

          {/* Cart */}
          <Link href="/cart" style={{ position: 'relative', textDecoration: 'none' }}>
            <button style={{
              width: 40, height: 40, borderRadius: 'var(--r-md)',
              background: 'var(--surface)', border: '1.5px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', transition: 'all 0.15s', boxShadow: 'var(--shadow-sm)',
            }}>
              <ShoppingCart size={18} color="var(--text-primary)" strokeWidth={2} />
              {cartItems.length > 0 && (
                <span style={{
                  position: 'absolute', top: -4, right: -4,
                  minWidth: 18, height: 18, borderRadius: '50%',
                  background: 'var(--rose)', color: 'white',
                  fontSize: '0.65rem', fontWeight: 800,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {cartItems.length}
                </span>
              )}
            </button>
          </Link>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="show-mobile"
            style={{
              width: 40, height: 40, borderRadius: 'var(--r-md)',
              background: 'var(--surface)', border: '1.5px solid var(--border)',
              display: 'none', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer',
            }}
          >
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{
          background: 'var(--surface)', borderTop: '1px solid var(--border)',
          padding: '1rem 1.5rem',
        }}>
          {navLinks.map(({ href, label }) => (
            <Link
              key={href}
              href={href}
              onClick={() => setMenuOpen(false)}
              style={{
                display: 'block', padding: '0.75rem 0',
                borderBottom: '1px solid var(--border-light)',
                fontSize: '0.9rem', fontWeight: 600, textDecoration: 'none',
                color: pathname === href ? 'var(--accent)' : 'var(--text-primary)',
              }}
            >
              {label}
            </Link>
          ))}
        </div>
      )}

      <style jsx>{`
        @media (max-width: 768px) {
          .hidden-mobile { display: none !important; }
          .show-mobile { display: flex !important; }
        }
      `}</style>
    </nav>
  );
}
