'use client';

import { usePersonaStore } from '@/store/personaStore';
import { Brain, Zap, Search, Target } from 'lucide-react';

const PERSONA_CONFIG = {
  skimmer:    { icon: <Zap size={16} />, color: '#f97316', bg: '#fff4ec', label: 'Skimmer', desc: 'Fast browser. You like quick picks.' },
  researcher: { icon: <Search size={16} />, color: '#1a56db', bg: '#e8f3ff', label: 'Researcher', desc: 'Deep reader. You compare before buying.' },
  hunter:     { icon: <Target size={16} />, color: '#2db88a', bg: '#e8f8f3', label: 'Deal Hunter', desc: 'Smart shopper. You love a great deal.' },
  unknown:    { icon: <Brain size={16} />, color: '#7a96aa', bg: 'var(--surface-2)', label: 'Analyzing...', desc: 'Learning your shopping style.' },
};

export default function PersonaBadge() {
  const { persona, confidence, scores, signals } = usePersonaStore();
  const cfg = PERSONA_CONFIG[persona] ?? PERSONA_CONFIG.unknown;

  return (
    <div className="persona-card" style={{ background: 'var(--surface)' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '1rem' }}>
        <div style={{
          width: 34, height: 34, borderRadius: 'var(--r-sm)',
          background: cfg.bg, display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: cfg.color, flexShrink: 0,
        }}>
          {cfg.icon}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.375rem' }}>
            <span style={{ fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)' }}>Shadow Persona</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontWeight: 800, fontSize: '0.95rem', color: 'var(--text-primary)' }}>{cfg.label}</span>
            <span style={{ fontWeight: 800, fontSize: '0.875rem', color: cfg.color }}>{Math.round(confidence * 100)}%</span>
          </div>
        </div>
      </div>

      <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginBottom: '1rem', lineHeight: 1.5 }}>{cfg.desc}</p>

      {/* Score bars */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1rem' }}>
        {([
          ['Skimmer',    scores.skimmer,    '#f97316'],
          ['Researcher', scores.researcher, '#1a56db'],
          ['Hunter',     scores.hunter,     '#2db88a'],
        ] as const).map(([label, val, color]) => (
          <div key={label} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', width: 68, flexShrink: 0 }}>{label}</span>
            <div className="conf-bar" style={{ flex: 1 }}>
              <div className="conf-fill" style={{ width: `${Math.round((val ?? 0) * 100)}%`, background: color }} />
            </div>
            <span style={{ fontSize: '0.68rem', fontWeight: 700, color: 'var(--text-muted)', width: 28, textAlign: 'right' }}>
              {Math.round((val ?? 0) * 100)}%
            </span>
          </div>
        ))}
      </div>

      {/* Signals */}
      {signals && signals.length > 0 && (
        <div>
          <p style={{ fontSize: '0.67rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '0.5rem' }}>Detected Signals</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.375rem' }}>
            {signals.slice(0, 3).map((s, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.72rem', color: 'var(--text-secondary)' }}>
                <span style={{ color: 'var(--mint)', flexShrink: 0 }}>▸</span>
                {s}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
