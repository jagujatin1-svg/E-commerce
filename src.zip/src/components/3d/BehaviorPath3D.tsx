'use client';

/**
 * BehaviorPath3D — Visualizes the user's journey as a glowing 3D path.
 * Each behavioral event (click, hover, scroll, search) becomes a node
 * on the path. Nodes glow based on event type and recency.
 */
import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Line, Sphere, Html } from '@react-three/drei';
import * as THREE from 'three';

export interface BehaviorNode {
  id: string;
  type: 'click' | 'hover' | 'scroll' | 'search' | 'cart_add' | 'page_view';
  timestamp: number;
  productId?: string;
}

interface BehaviorPath3DProps {
  nodes: BehaviorNode[];
  maxNodes?: number;
}

const EVENT_COLORS: Record<BehaviorNode['type'], string> = {
  click:     '#6272f5',
  hover:     '#a78bfa',
  scroll:    '#22d3ee',
  search:    '#fbbf24',
  cart_add:  '#34d399',
  page_view: '#94a3b8',
};

const EVENT_ICONS: Record<BehaviorNode['type'], string> = {
  click:     '🖱️',
  hover:     '👁️',
  scroll:    '📜',
  search:    '🔍',
  cart_add:  '🛒',
  page_view: '📄',
};

function PathNode({ node, position, isRecent }: {
  node: BehaviorNode;
  position: [number, number, number];
  isRecent: boolean;
}) {
  const meshRef = useRef<THREE.Mesh>(null!);
  const color = EVENT_COLORS[node.type];

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const mat = meshRef.current.material as THREE.MeshStandardMaterial;
    mat.emissiveIntensity = isRecent
      ? 0.6 + Math.sin(clock.elapsedTime * 3) * 0.4
      : 0.2;
  });

  return (
    <group position={position}>
      <mesh ref={meshRef}>
        <sphereGeometry args={[isRecent ? 0.14 : 0.09, 16, 16]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={isRecent ? 0.8 : 0.2}
          roughness={0.1}
          metalness={0.7}
          transparent
          opacity={isRecent ? 1 : 0.6}
        />
      </mesh>
      {isRecent && (
        <Html distanceFactor={6} center>
          <div style={{
            fontSize: '0.65rem',
            background: 'rgba(0,0,0,0.7)',
            border: `1px solid ${color}44`,
            color: '#e2e8f0',
            padding: '2px 6px',
            borderRadius: '6px',
            whiteSpace: 'nowrap',
            backdropFilter: 'blur(4px)',
          }}>
            {EVENT_ICONS[node.type]} {node.type.replace('_', ' ')}
          </div>
        </Html>
      )}
    </group>
  );
}

export default function BehaviorPath3D({ nodes, maxNodes = 20 }: BehaviorPath3DProps) {
  const recent = nodes.slice(-maxNodes);

  // Arrange nodes in a flowing 3D helix path
  const positions = useMemo<[number, number, number][]>(() => {
    return recent.map((_, i) => {
      const t = (i / Math.max(recent.length - 1, 1));
      const angle = t * Math.PI * 3;
      return [
        Math.cos(angle) * (1.5 + t),
        -2 + t * 4,
        Math.sin(angle) * (1.5 + t) - 3,
      ];
    });
  }, [recent]);

  if (positions.length < 2) return null;

  return (
    <group>
      {/* Connecting line */}
      <Line
        points={positions}
        color="#6272f5"
        lineWidth={1.5}
        transparent
        opacity={0.5}
        dashed
        dashSize={0.15}
        gapSize={0.05}
      />

      {/* Nodes */}
      {recent.map((node, i) => (
        <PathNode
          key={node.id}
          node={node}
          position={positions[i]}
          isRecent={i >= recent.length - 3}
        />
      ))}
    </group>
  );
}
