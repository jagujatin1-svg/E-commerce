'use client';

/**
 * RecommendationCluster3D — Floating cluster of recommended products in 3D space.
 * Products orbit a central glowing orb. Cluster layout changes based on persona:
 * - Skimmer: tight fast orbit
 * - Researcher: wide slow orbit
 * - Hunter: spotlight center with radial bursts
 */
import { useRef, useMemo, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html, Sphere } from '@react-three/drei';
import { useSpring, animated } from '@react-spring/three';
import * as THREE from 'three';
import { Product } from '@/lib/api';
import { PersonaType, DynamicPrice } from '@/store/personaStore';

interface RecommendationCluster3DProps {
  products: Product[];
  persona: PersonaType;
  priceMap: Record<string, DynamicPrice>;
  onSelectProduct?: (product: Product) => void;
}

const PERSONA_ORBIT: Record<PersonaType, { radius: number; speed: number; spread: number }> = {
  skimmer:    { radius: 3.5, speed: 1.4,  spread: 0.4 },
  researcher: { radius: 5.0, speed: 0.4,  spread: 0.8 },
  hunter:     { radius: 4.0, speed: 0.9,  spread: 0.2 },
  unknown:    { radius: 4.0, speed: 0.6,  spread: 0.5 },
};

const PERSONA_COLOR: Record<PersonaType, string> = {
  skimmer:    '#22d3ee',
  researcher: '#6272f5',
  hunter:     '#34d399',
  unknown:    '#4b5563',
};

function getCategoryEmoji(category: string): string {
  const map: Record<string, string> = {
    Electronics: '💻', Audio: '🎧', Gaming: '🎮', Photography: '📷',
    Wearables: '⌚', 'Mobile Phones': '📱', Accessories: '🔌',
  };
  return map[category] ?? '📦';
}

// Central pulsing orb
function CentralOrb({ color }: { color: string }) {
  const meshRef = useRef<THREE.Mesh>(null!);
  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const mat = meshRef.current.material as THREE.MeshStandardMaterial;
    mat.emissiveIntensity = 0.5 + Math.sin(clock.elapsedTime * 2) * 0.3;
    meshRef.current.rotation.y = clock.elapsedTime * 0.5;
  });
  return (
    <mesh ref={meshRef}>
      <icosahedronGeometry args={[0.5, 2]} />
      <meshStandardMaterial
        color={color}
        emissive={color}
        emissiveIntensity={0.7}
        roughness={0.1}
        metalness={0.9}
        wireframe={false}
      />
    </mesh>
  );
}

// Single orbiting product node
function OrbitNode({
  product,
  price,
  orbitRadius,
  orbitSpeed,
  orbitOffset,
  heightOffset,
  personaColor,
  onSelect,
}: {
  product: Product;
  price?: DynamicPrice;
  orbitRadius: number;
  orbitSpeed: number;
  orbitOffset: number;
  heightOffset: number;
  personaColor: string;
  onSelect?: () => void;
}) {
  const groupRef = useRef<THREE.Group>(null!);
  const [hovered, setHovered] = useState(false);
  const hasDiscount = (price?.discount_pct ?? 0) > 0.5;

  const { scale } = useSpring({
    scale: hovered ? 1.3 : 1,
    config: { tension: 300, friction: 15 },
  });

  useFrame(({ clock }) => {
    if (!groupRef.current) return;
    const t = clock.elapsedTime * orbitSpeed + orbitOffset;
    groupRef.current.position.x = Math.cos(t) * orbitRadius;
    groupRef.current.position.z = Math.sin(t) * orbitRadius;
    groupRef.current.position.y = heightOffset + Math.sin(t * 0.7) * 0.3;
  });

  return (
    <animated.group
      ref={groupRef}
      scale={scale}
      onPointerEnter={() => { setHovered(true); document.body.style.cursor = 'pointer'; }}
      onPointerLeave={() => { setHovered(false); document.body.style.cursor = 'auto'; }}
      onClick={onSelect}
    >
      {/* Product sphere */}
      <mesh>
        <sphereGeometry args={[0.35, 20, 20]} />
        <meshStandardMaterial
          color="#0f0f1a"
          emissive={personaColor}
          emissiveIntensity={hovered ? 0.7 : 0.25}
          roughness={0.2}
          metalness={0.8}
          transparent
          opacity={0.95}
        />
      </mesh>

      {/* Emoji overlay */}
      <Html center distanceFactor={5}>
        <div style={{
          fontSize: '1.2rem',
          userSelect: 'none',
          filter: `drop-shadow(0 0 6px ${personaColor})`,
        }}>
          {getCategoryEmoji(product.category)}
        </div>
      </Html>

      {/* Hover card */}
      {hovered && (
        <Html position={[0.5, 0.6, 0]} distanceFactor={5}>
          <div style={{
            background: 'rgba(10,10,20,0.9)',
            border: `1px solid ${personaColor}44`,
            borderRadius: '10px',
            padding: '8px 12px',
            minWidth: '140px',
            backdropFilter: 'blur(8px)',
            boxShadow: `0 0 20px ${personaColor}33`,
          }}>
            <p style={{ color: '#e2e8f0', fontSize: '0.7rem', fontWeight: 700, marginBottom: 4 }}>
              {product.name.slice(0, 22)}{product.name.length > 22 ? '…' : ''}
            </p>
            <p style={{ color: hasDiscount ? '#34d399' : '#fff', fontSize: '0.85rem', fontWeight: 900 }}>
              ${(price?.final_price ?? product.base_price).toFixed(2)}
            </p>
            {hasDiscount && (
              <p style={{ color: '#fbbf24', fontSize: '0.6rem' }}>-{Math.round(price!.discount_pct)}% off</p>
            )}
            <p style={{ color: '#64748b', fontSize: '0.6rem', marginTop: 3 }}>Click to view</p>
          </div>
        </Html>
      )}
    </animated.group>
  );
}

export default function RecommendationCluster3D({
  products,
  persona,
  priceMap,
  onSelectProduct,
}: RecommendationCluster3DProps) {
  const config = PERSONA_ORBIT[persona];
  const color = PERSONA_COLOR[persona];

  // Distribute products on orbit with spread in height
  const nodes = useMemo(() => products.slice(0, 8).map((p, i) => ({
    product: p,
    offset: (i / products.length) * Math.PI * 2,
    height: (Math.random() - 0.5) * config.spread * 2,
  })), [products, config.spread]);

  return (
    <group>
      <CentralOrb color={color} />

      {nodes.map(({ product, offset, height }) => (
        <OrbitNode
          key={product.id}
          product={product}
          price={priceMap[product.id]}
          orbitRadius={config.radius}
          orbitSpeed={config.speed}
          orbitOffset={offset}
          heightOffset={height}
          personaColor={color}
          onSelect={() => onSelectProduct?.(product)}
        />
      ))}
    </group>
  );
}
