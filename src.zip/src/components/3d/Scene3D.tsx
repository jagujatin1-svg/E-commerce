'use client';

/**
 * Scene3D — Main Three.js/R3F scene orchestrator.
 * Composes: PersonaEnvironment + ProductShowcase + RecommendationCluster + BehaviorPath
 * Camera auto-orbits gently; user can drag to override.
 * View mode switches between 'showcase', 'cluster', and 'path'.
 */
import { Suspense, useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Stats, AdaptiveDpr } from '@react-three/drei';
import * as THREE from 'three';
import PersonaEnvironment3D from './PersonaEnvironment3D';
import ProductShowcase3D from './ProductShowcase3D';
import RecommendationCluster3D from './RecommendationCluster3D';
import BehaviorPath3D, { BehaviorNode } from './BehaviorPath3D';
import { DynamicPrice, PersonaType } from '@/store/personaStore';
import { Product } from '@/lib/api';

// Re-export for consumers
export type { BehaviorNode };

export type SceneView = 'showcase' | 'cluster' | 'path';

interface Scene3DProps {
  products: Product[];
  persona: PersonaType;
  priceMap: Record<string, DynamicPrice>;
  behaviorNodes: BehaviorNode[];
  view: SceneView;
  onSelectProduct?: (product: Product) => void;
  showStats?: boolean;
}

// Camera that gently auto-orbits when user is not interacting
function AutoOrbitCamera({ active }: { active: boolean }) {
  const { camera } = useThree();
  const angle = useRef(0);
  useFrame((_, delta) => {
    if (!active) return;
    angle.current += delta * 0.08;
    camera.position.x = Math.sin(angle.current) * 10;
    camera.position.z = Math.cos(angle.current) * 10;
    camera.lookAt(0, 0, 0);
  });
  return null;
}

// Loading fallback — pulsing ring
function SceneLoader() {
  const meshRef = useRef<THREE.Mesh>(null!);
  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    meshRef.current.rotation.z = clock.elapsedTime;
    meshRef.current.rotation.x = clock.elapsedTime * 0.5;
  });
  return (
    <mesh ref={meshRef}>
      <torusGeometry args={[1.2, 0.05, 8, 60]} />
      <meshStandardMaterial color="#6272f5" emissive="#6272f5" emissiveIntensity={1.5} />
    </mesh>
  );
}

export default function Scene3D({
  products,
  persona,
  priceMap,
  behaviorNodes,
  view,
  onSelectProduct,
  showStats = false,
}: Scene3DProps) {
  const [pixelRatio, setPixelRatio] = useState(1);

  useEffect(() => {
    setPixelRatio(Math.min(window.devicePixelRatio ?? 1, 2));
  }, []);

  const [autoOrbit, setAutoOrbit] = useState(true);

  return (
    <Canvas
      gl={{
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance',
      }}
      dpr={[1, pixelRatio]}
      onPointerDown={() => setAutoOrbit(false)}
      style={{ background: 'transparent' }}
    >
      {/* Adaptive DPR for performance */}
      <AdaptiveDpr pixelated />

      {/* Camera */}
      <PerspectiveCamera makeDefault position={[0, 1.5, 10]} fov={55} />
      <AutoOrbitCamera active={autoOrbit} />
      <OrbitControls
        enablePan={false}
        enableZoom
        minDistance={4}
        maxDistance={20}
        maxPolarAngle={Math.PI / 1.4}
        onStart={() => setAutoOrbit(false)}
      />

      {/* Scene environment */}
      <PersonaEnvironment3D persona={persona} />

      {/* Main content by view */}
      <Suspense fallback={<SceneLoader />}>
        {view === 'showcase' && (
          <ProductShowcase3D
            products={products}
            persona={persona}
            priceMap={priceMap}
            onSelectProduct={onSelectProduct}
          />
        )}
        {view === 'cluster' && (
          <RecommendationCluster3D
            products={products}
            persona={persona}
            priceMap={priceMap}
            onSelectProduct={onSelectProduct}
          />
        )}
        {view === 'path' && (
          <BehaviorPath3D nodes={behaviorNodes} />
        )}
      </Suspense>

      {showStats && <Stats />}
    </Canvas>
  );
}
