'use client';

/**
 * ProductShowcase3D — Persona-layout product carousel.
 *
 * Skimmer   → Fast horizontal scrolling carousel (flow layout)
 * Researcher → Wide grid with detail panels visible
 * Hunter     → Spotlight center with flanking discounted items
 */
import { useRef, useState, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useSpring, animated } from '@react-spring/three';
import * as THREE from 'three';
import ProductCard3D from './ProductCard3D';
import { Product } from '@/lib/api';
import { PersonaType, DynamicPrice } from '@/store/personaStore';

interface ProductShowcase3DProps {
  products: Product[];
  persona: PersonaType;
  priceMap: Record<string, DynamicPrice>;
  onSelectProduct?: (product: Product) => void;
}

// Skimmer: tight horizontal flow
function SkimmerLayout({ products, priceMap, onSelect }: {
  products: Product[];
  priceMap: Record<string, DynamicPrice>;
  onSelect?: (p: Product) => void;
}) {
  const groupRef = useRef<THREE.Group>(null!);
  useFrame(({ clock }) => {
    if (!groupRef.current) return;
    groupRef.current.position.x = -Math.sin(clock.elapsedTime * 0.3) * 2;
  });

  return (
    <group ref={groupRef}>
      {products.slice(0, 6).map((p, i) => (
        <ProductCard3D
          key={p.id}
          product={p}
          dynamicPrice={priceMap[p.id]}
          position={[(i - 2.5) * 2.6, 0, 0]}
          onClick={() => onSelect?.(p)}
        />
      ))}
    </group>
  );
}

// Researcher: wider spread with depth
function ResearcherLayout({ products, priceMap, onSelect }: {
  products: Product[];
  priceMap: Record<string, DynamicPrice>;
  onSelect?: (p: Product) => void;
}) {
  return (
    <group>
      {products.slice(0, 6).map((p, i) => {
        const row = Math.floor(i / 3);
        const col = i % 3;
        return (
          <ProductCard3D
            key={p.id}
            product={p}
            dynamicPrice={priceMap[p.id]}
            position={[(col - 1) * 2.8, row * -3.5 + 1.2, row * -0.4]}
            onClick={() => onSelect?.(p)}
          />
        );
      })}
    </group>
  );
}

// Hunter: center spotlight + flanking deals
function HunterLayout({ products, priceMap, onSelect }: {
  products: Product[];
  priceMap: Record<string, DynamicPrice>;
  onSelect?: (p: Product) => void;
}) {
  const sorted = [...products]
    .filter(p => priceMap[p.id])
    .sort((a, b) => (priceMap[b.id]?.discount_pct ?? 0) - (priceMap[a.id]?.discount_pct ?? 0))
    .slice(0, 5);

  return (
    <group>
      {/* Center deal */}
      {sorted[0] && (
        <ProductCard3D
          product={sorted[0]}
          dynamicPrice={priceMap[sorted[0].id]}
          position={[0, 0, 0]}
          isHighlighted
          onClick={() => onSelect?.(sorted[0])}
        />
      )}
      {/* Flanking */}
      {sorted.slice(1, 5).map((p, i) => {
        const angle = (i / 4) * Math.PI * 2 - Math.PI / 4;
        return (
          <ProductCard3D
            key={p.id}
            product={p}
            dynamicPrice={priceMap[p.id]}
            position={[Math.cos(angle) * 4.2, Math.sin(angle * 0.5) * 0.5, Math.sin(angle) * -1]}
            onClick={() => onSelect?.(p)}
          />
        );
      })}
    </group>
  );
}

export default function ProductShowcase3D({
  products,
  persona,
  priceMap,
  onSelectProduct,
}: ProductShowcase3DProps) {
  if (products.length === 0) return null;

  if (persona === 'skimmer') {
    return <SkimmerLayout products={products} priceMap={priceMap} onSelect={onSelectProduct} />;
  }
  if (persona === 'researcher') {
    return <ResearcherLayout products={products} priceMap={priceMap} onSelect={onSelectProduct} />;
  }
  if (persona === 'hunter') {
    return <HunterLayout products={products} priceMap={priceMap} onSelect={onSelectProduct} />;
  }
  // Default (unknown): simple centered row
  return <SkimmerLayout products={products} priceMap={priceMap} onSelect={onSelectProduct} />;
}
