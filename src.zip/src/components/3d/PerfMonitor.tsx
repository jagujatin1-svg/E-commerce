'use client';

/**
 * PerfMonitor — lightweight in-app FPS + latency display.
 * Shows FPS and WebSocket latency. Auto-hides when FPS > 50.
 * Also writes to the persona store for graceful degradation logic.
 */
import { useEffect, useRef, useState } from 'react';
import { Cpu, Wifi } from 'lucide-react';

interface PerfMonitorProps {
  wsLatency?: number;
  onLowFPS?: (fps: number) => void;
}

export default function PerfMonitor({ wsLatency, onLowFPS }: PerfMonitorProps) {
  const [fps, setFps] = useState<number | null>(null);
  const frameCount = useRef(0);
  const lastTime = useRef(performance.now());
  const rafId = useRef<number>();
  const [lowFPS, setLowFPS] = useState(false);

  useEffect(() => {
    const measure = () => {
      frameCount.current++;
      const now = performance.now();
      if (now - lastTime.current >= 1000) {
        const currentFps = Math.round(frameCount.current * 1000 / (now - lastTime.current));
        setFps(currentFps);
        frameCount.current = 0;
        lastTime.current = now;
        if (currentFps < 30) {
          setLowFPS(true);
          onLowFPS?.(currentFps);
        } else {
          setLowFPS(false);
        }
      }
      rafId.current = requestAnimationFrame(measure);
    };
    rafId.current = requestAnimationFrame(measure);
    return () => { if (rafId.current) cancelAnimationFrame(rafId.current); };
  }, [onLowFPS]);

  if (!fps) return null;

  const fpsColor = fps >= 50 ? '#34d399' : fps >= 30 ? '#fbbf24' : '#f87171';

  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center gap-3 glass rounded-xl px-4 py-2 text-xs border border-white/5">
      <div className="flex items-center gap-1.5">
        <Cpu className="w-3.5 h-3.5" style={{ color: fpsColor }} />
        <span style={{ color: fpsColor }} className="font-bold">{fps} FPS</span>
      </div>
      {wsLatency !== undefined && (
        <div className="flex items-center gap-1.5">
          <Wifi className={`w-3.5 h-3.5 ${wsLatency < 50 ? 'text-emerald-400' : 'text-yellow-400'}`} />
          <span className={`font-bold ${wsLatency < 50 ? 'text-emerald-400' : 'text-yellow-400'}`}>
            {wsLatency}ms
          </span>
        </div>
      )}
      {lowFPS && (
        <span className="text-yellow-400">⚠ Low perf</span>
      )}
    </div>
  );
}
