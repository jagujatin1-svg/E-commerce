'use client';

/**
 * PersonaEnvironment3D — The scene background/environment that transforms
 * based on the current shadow persona. Each persona gets a unique color
 * palette, particle density, and ambient movement.
 *
 * Skimmer   → Fast-moving cyan particles, energetic
 * Researcher → Slow, dense blue particles, methodical
 * Hunter     → Green pulsing particles, focused spotlight
 * Unknown    → Neutral dark nebula
 */
import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useSpring, animated } from '@react-spring/three';
import * as THREE from 'three';
import { PersonaType } from '@/store/personaStore';

const PERSONA_CONFIGS: Record<PersonaType, {
  particleColor: string;
  fogColor: string;
  speed: number;
  count: number;
  ambientIntensity: number;
}> = {
  skimmer: {
    particleColor: '#22d3ee',
    fogColor: '#040d14',
    speed: 2.5,
    count: 200,
    ambientIntensity: 0.6,
  },
  researcher: {
    particleColor: '#6272f5',
    fogColor: '#04040f',
    speed: 0.5,
    count: 300,
    ambientIntensity: 0.4,
  },
  hunter: {
    particleColor: '#34d399',
    fogColor: '#011a0d',
    speed: 1.2,
    count: 150,
    ambientIntensity: 0.55,
  },
  unknown: {
    particleColor: '#4b5563',
    fogColor: '#050508',
    speed: 0.8,
    count: 100,
    ambientIntensity: 0.25,
  },
};

interface PersonaEnvironment3DProps {
  persona: PersonaType;
}

function ParticleField({ persona }: { persona: PersonaType }) {
  const meshRef = useRef<THREE.Points>(null!);
  const config = PERSONA_CONFIGS[persona];

  const { positions, speeds } = useMemo(() => {
    const n = config.count;
    const pos = new Float32Array(n * 3);
    const spd = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      pos[i * 3]     = (Math.random() - 0.5) * 30;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 20;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 20 - 5;
      spd[i] = Math.random() * config.speed;
    }
    return { positions: pos, speeds: spd };
  }, [config.count, config.speed]);

  useFrame(({ clock }) => {
    if (!meshRef.current) return;
    const pos = meshRef.current.geometry.attributes.position.array as Float32Array;
    const t = clock.elapsedTime;
    for (let i = 0; i < config.count; i++) {
      pos[i * 3 + 1] += speeds[i] * 0.005;
      if (pos[i * 3 + 1] > 10) pos[i * 3 + 1] = -10;
      // Small lateral drift for skimmer
      if (persona === 'skimmer') {
        pos[i * 3] += Math.sin(t + i) * 0.005;
      }
    }
    meshRef.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
          count={config.count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        color={config.particleColor}
        size={0.06}
        sizeAttenuation
        transparent
        opacity={0.7}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
}

// Spotlight for hunter persona
function HunterSpotlight() {
  const lightRef = useRef<THREE.SpotLight>(null!);
  useFrame(({ clock }) => {
    if (!lightRef.current) return;
    lightRef.current.position.x = Math.sin(clock.elapsedTime * 0.4) * 3;
  });
  return (
    <spotLight
      ref={lightRef}
      color="#34d399"
      intensity={4}
      position={[0, 10, 2]}
      angle={0.3}
      penumbra={0.8}
      castShadow={false}
    />
  );
}

export default function PersonaEnvironment3D({ persona }: PersonaEnvironment3DProps) {
  const config = PERSONA_CONFIGS[persona];

  const { ambientIntensity } = useSpring({
    ambientIntensity: config.ambientIntensity,
    config: { duration: 1500 },
  });

  return (
    <>
      <fog attach="fog" args={[config.fogColor, 8, 35]} />
      <animated.ambientLight intensity={ambientIntensity} color={config.particleColor} />
      <pointLight position={[0, 5, 0]} intensity={1.5} color={config.particleColor} />
      {persona === 'hunter' && <HunterSpotlight />}
      <ParticleField persona={persona} />
    </>
  );
}
