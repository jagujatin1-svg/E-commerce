'use client';

/**
 * ProductCard3D — A rotating 3D card for a single product.
 * Shows the product emoji on a glassmorphic 3D panel that
 * rotates on hover and pulses when price changes.
 */
import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { RoundedBox, Text, Html } from '@react-three/drei';
import { useSpring, animated } from '@react-spring/three';
import * as THREE from 'three';
import { Product } from '@/lib/api';
import { DynamicPrice } from '@/store/personaStore';

interface ProductCard3DProps {
  product: Product;
  dynamicPrice?: DynamicPrice | null;
  position?: [number, number, number];
  onClick?: () => void;
  isHighlighted?: boolean;
}

const CATEGORY_COLORS: Record<string, string> = {
  Electronics: '#6272f5',
  Audio: '#a78bfa',
  Gaming: '#34d399',
  Photography: '#fbbf24',
  Wearables: '#22d3ee',
  'Mobile Phones': '#f87171',
  Accessories: '#fb923c',
};

function getCategoryEmoji(cat: string) {
  const m: Record<string, string> = {
    Electronics: '💻', Audio: '🎧', Gaming: '🎮',
    Photography: '📷', Wearables: '⌚', 'Mobile Phones': '📱',
    Accessories: '🔌',
  };
  return m[cat] ?? '📦';
}

export default function ProductCard3D({
  product,
  dynamicPrice,
  position = [0, 0, 0],
  onClick,
  isHighlighted = false,
}: ProductCard3DProps) {
  const groupRef = useRef<THREE.Group>(null!);
  const [hovered, setHovered] = useState(false);
  const color = CATEGORY_COLORS[product.category] ?? '#6272f5';
  const hasDiscount = (dynamicPrice?.discount_pct ?? 0) > 0.5;
  const displayPrice = dynamicPrice?.final_price ?? product.base_price;

  // Spring for hover lift + scale
  const { scale, rotY, emissiveIntensity } = useSpring({
    scale: hovered ? 1.08 : isHighlighted ? 1.04 : 1,
    rotY: hovered ? 0.25 : 0,
    emissiveIntensity: hovered ? 0.4 : isHighlighted ? 0.25 : 0.08,
    config: { mass: 1, tension: 200, friction: 20 },
  });

  // Idle float
  useFrame(({ clock }) => {
    if (!groupRef.current) return;
    groupRef.current.position.y =
      position[1] + Math.sin(clock.elapsedTime * 0.8 + position[0]) * 0.06;
  });

  return (
    <animated.group
      ref={groupRef}
      position={position}
      scale={scale}
      rotation-y={rotY}
      onClick={onClick}
      onPointerEnter={() => { setHovered(true); document.body.style.cursor = 'pointer'; }}
      onPointerLeave={() => { setHovered(false); document.body.style.cursor = 'auto'; }}
    >
      {/* Card body */}
      <RoundedBox args={[2.2, 3, 0.12]} radius={0.12} smoothness={4}>
        <animated.meshStandardMaterial
          color="#0f0f1a"
          emissive={color}
          emissiveIntensity={emissiveIntensity}
          roughness={0.2}
          metalness={0.6}
          transparent
          opacity={0.92}
        />
      </RoundedBox>

      {/* Glow border */}
      <RoundedBox args={[2.25, 3.05, 0.08]} radius={0.13} smoothness={4}>
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={hovered ? 0.6 : 0.15}
          transparent
          opacity={0.3}
          wireframe={false}
        />
      </RoundedBox>

      {/* Product emoji as HTML overlay */}
      <Html center position={[0, 0.7, 0.07]} distanceFactor={5}>
        <div style={{
          fontSize: '2.5rem',
          filter: `drop-shadow(0 0 12px ${color})`,
          userSelect: 'none',
          transition: 'transform 0.3s',
          transform: hovered ? 'scale(1.2) rotate(5deg)' : 'scale(1)',
        }}>
          {getCategoryEmoji(product.category)}
        </div>
      </Html>

      {/* Product name */}
      <Text
        position={[0, -0.15, 0.07]}
        fontSize={0.18}
        maxWidth={1.9}
        textAlign="center"
        color="#e2e8f0"
        anchorX="center"
        anchorY="middle"
      >
        {product.name.length > 28 ? product.name.slice(0, 28) + '…' : product.name}
      </Text>

      {/* Price */}
      <Text
        position={[0, -0.65, 0.07]}
        fontSize={0.28}
        color={hasDiscount ? '#34d399' : '#ffffff'}
        anchorX="center"
        anchorY="middle"
      >
        ${displayPrice.toFixed(2)}
      </Text>

      {/* Discount badge */}
      {hasDiscount && (
        <Text
          position={[0, -0.98, 0.07]}
          fontSize={0.14}
          color="#fbbf24"
          anchorX="center"
          anchorY="middle"
        >
          -{Math.round(dynamicPrice!.discount_pct)}% OFF
        </Text>
      )}

      {/* Demand indicator dot */}
      {product.demand_score > 0.7 && (
        <mesh position={[0.85, 1.3, 0.08]}>
          <sphereGeometry args={[0.08, 16, 16]} />
          <meshStandardMaterial
            color="#f97316"
            emissive="#f97316"
            emissiveIntensity={1.2}
          />
        </mesh>
      )}
    </animated.group>
  );
}
