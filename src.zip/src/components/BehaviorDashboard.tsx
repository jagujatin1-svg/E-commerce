'use client';

import { usePersonaStore } from '@/store/personaStore';
import { Activity, Zap, Target, Clock, BarChart2, MousePointerClick } from 'lucide-react';

export default function BehaviorDashboard() {
  const { persona, confidence, scores, signals, features, isConnected, lastUpdated } = usePersonaStore();

  const timeAgo = lastUpdated ? Math.round((Date.now() - lastUpdated) / 1000) : null;

  const personaColor = {
    skimmer: '#fbbf24',
    researcher: '#6272f5',
    hunter: '#34d399',
    unknown: '#4b5563',
  }[persona];

  const statCards = [
    {
      icon: <MousePointerClick className="w-4 h-4" />,
      label: 'Total Events',
      value: features?.total_events ?? 0,
      color: '#6272f5',
    },
    {
      icon: <Activity className="w-4 h-4" />,
      label: 'Engagement',
      value: `${Math.round((features?.engagement_score ?? 0) * 100)}%`,
      color: '#a78bfa',
    },
    {
      icon: <Target className="w-4 h-4" />,
      label: 'Purchase Intent',
      value: `${Math.round((features?.purchase_intent ?? 0) * 100)}%`,
      color: '#34d399',
    },
    {
      icon: <Clock className="w-4 h-4" />,
      label: 'Avg Hover',
      value: `${Math.round(features?.avg_hover_duration ?? 0)}ms`,
      color: '#fbbf24',
    },
    {
      icon: <Zap className="w-4 h-4" />,
      label: 'Events/Min',
      value: (features?.events_per_minute ?? 0).toFixed(1),
      color: '#f87171',
    },
    {
      icon: <BarChart2 className="w-4 h-4" />,
      label: 'Confidence',
      value: `${Math.round(confidence * 100)}%`,
      color: personaColor,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Status header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
          <span className={`text-sm ${isConnected ? 'text-emerald-400' : 'text-slate-500'}`}>
            {isConnected ? 'Live tracking active' : 'Connecting…'}
          </span>
        </div>
        {timeAgo !== null && (
          <span className="text-slate-500 text-xs">Updated {timeAgo}s ago</span>
        )}
      </div>

      {/* Stat cards grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {statCards.map(({ icon, label, value, color }) => (
          <div key={label} className="glass rounded-xl p-4 border border-white/5 glass-hover">
            <div className="flex items-center gap-2 mb-2" style={{ color }}>
              {icon}
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">{label}</span>
            </div>
            <p className="text-white font-bold text-xl">{value}</p>
          </div>
        ))}
      </div>

      {/* Score breakdown */}
      <div className="glass rounded-2xl p-5 border border-white/5">
        <h3 className="text-white font-semibold mb-4">Persona Score Breakdown</h3>
        <div className="space-y-4">
          {[
            { key: 'skimmer',    label: '⚡ Skimmer',    color: '#fbbf24', desc: 'Fast browser, impulse buyer' },
            { key: 'researcher', label: '🔬 Researcher', color: '#6272f5', desc: 'Deep reader, comparison buyer' },
            { key: 'hunter',     label: '🎯 Hunter',     color: '#34d399', desc: 'Deal seeker, high intent' },
          ].map(({ key, label, color, desc }) => {
            const score = scores[key as keyof typeof scores] ?? 0;
            const isActive = persona === key;
            return (
              <div key={key} className={`p-3 rounded-xl transition-all ${isActive ? 'bg-white/5 border border-white/10' : ''}`}>
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <span className="text-white text-sm font-semibold">{label}</span>
                    {isActive && <span className="ml-2 text-xs px-1.5 py-0.5 rounded-full" style={{ background: color + '33', color }}>Active</span>}
                    <p className="text-slate-500 text-xs mt-0.5">{desc}</p>
                  </div>
                  <span className="text-white font-bold">{Math.round(score * 100)}%</span>
                </div>
                <div className="confidence-bar">
                  <div
                    className="confidence-fill"
                    style={{ width: `${Math.round(score * 100)}%`, background: color }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Live signals */}
      <div className="glass rounded-2xl p-5 border border-white/5">
        <h3 className="text-white font-semibold mb-3">Detected Behavioral Signals</h3>
        {signals.length === 0 ? (
          <p className="text-slate-500 text-sm">Browse some products to generate signals…</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {signals.map((signal, i) => (
              <span key={i} className="text-sm bg-white/5 border border-white/8 text-slate-300 px-3 py-1.5 rounded-full">
                {signal}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
