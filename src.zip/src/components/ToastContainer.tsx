'use client';

import { usePersonaStore } from '@/store/personaStore';
import { CheckCircle, AlertCircle, Info, X } from 'lucide-react';

export default function ToastContainer() {
  const { toasts, removeToast } = usePersonaStore();

  if (!toasts.length) return null;

  return (
    <div style={{
      position: 'fixed',
      bottom: '1.5rem',
      right: '1.5rem',
      zIndex: 99999,
      display: 'flex',
      flexDirection: 'column',
      gap: '0.625rem',
      maxWidth: '340px',
      width: '100%',
    }}>
      {toasts.map((toast) => {
        const configs = {
          success: {
            icon: <CheckCircle size={16} />,
            bg: '#ffffff',
            border: '1.5px solid #2db88a',
            iconColor: '#2db88a',
            textColor: '#0d1117',
          },
          error: {
            icon: <AlertCircle size={16} />,
            bg: '#ffffff',
            border: '1.5px solid #e11d48',
            iconColor: '#e11d48',
            textColor: '#0d1117',
          },
          info: {
            icon: <Info size={16} />,
            bg: '#ffffff',
            border: '1.5px solid #1a56db',
            iconColor: '#1a56db',
            textColor: '#0d1117',
          },
        };
        const cfg = configs[toast.type];
        return (
          <div
            key={toast.id}
            style={{
              background: cfg.bg,
              border: cfg.border,
              borderRadius: '12px',
              padding: '0.75rem 1rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.625rem',
              boxShadow: '0 4px 24px rgba(13,17,23,0.12), 0 1px 4px rgba(13,17,23,0.06)',
              animation: 'slideInToast 0.25s ease-out',
            }}
          >
            <span style={{ color: cfg.iconColor, flexShrink: 0 }}>{cfg.icon}</span>
            <p style={{ flex: 1, color: cfg.textColor, fontSize: '0.85rem', fontWeight: 600, lineHeight: 1.4 }}>
              {toast.message}
            </p>
            <button
              onClick={() => removeToast(toast.id)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', flexShrink: 0, padding: '0.1rem', lineHeight: 1 }}
            >
              <X size={13} />
            </button>
          </div>
        );
      })}
      <style jsx global>{`
        @keyframes slideInToast {
          from { transform: translateX(110%); opacity: 0; }
          to   { transform: translateX(0); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
