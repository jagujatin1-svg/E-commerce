'use client';

import { useEffect, useRef, useState } from 'react';
import { usePersonaStore, DynamicPrice } from '@/store/personaStore';
import { TrendingDown, TrendingUp } from 'lucide-react';

interface PriceTagProps {
  productId: string;
  basePrice: number;
  large?: boolean;
}

export default function PriceTag({ productId, basePrice, large = false }: PriceTagProps) {
  const { priceMap } = usePersonaStore();
  const dynamicPrice: DynamicPrice | undefined = priceMap[productId];
  const prevPriceRef = useRef<number>(dynamicPrice?.final_price ?? basePrice);
  const [changed, setChanged] = useState(false);
  const [direction, setDirection] = useState<'up' | 'down' | 'same'>('same');

  const displayPrice = dynamicPrice?.final_price ?? basePrice;
  const discount = dynamicPrice?.discount_pct ?? 0;
  const hasDiscount = discount > 0.5;

  useEffect(() => {
    const prev = prevPriceRef.current;
    if (Math.abs(displayPrice - prev) > 0.01) {
      setDirection(displayPrice < prev ? 'down' : 'up');
      setChanged(true);
      setTimeout(() => setChanged(false), 600);
      prevPriceRef.current = displayPrice;
    }
  }, [displayPrice]);

  const sizeClass = large ? 'text-3xl' : 'text-xl';

  return (
    <div className="flex flex-col">
      <div className="flex items-baseline gap-3 flex-wrap">
        <span className={`text-white font-black ${sizeClass} ${changed ? 'price-changed' : ''}`}>
          ₹{displayPrice.toLocaleString('en-IN')}
        </span>
        {hasDiscount && (
          <span className="text-slate-500 line-through text-sm">
            ₹{basePrice.toLocaleString('en-IN')}
          </span>
        )}
        {changed && (
          <span className={`flex items-center gap-0.5 text-xs font-semibold ${direction === 'down' ? 'text-emerald-400' : 'text-red-400'}`}>
            {direction === 'down' ? <TrendingDown className="w-3.5 h-3.5" /> : <TrendingUp className="w-3.5 h-3.5" />}
            {direction === 'down' ? 'Price dropped!' : 'Price updated'}
          </span>
        )}
      </div>

      {hasDiscount && (
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          <span className="bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-bold px-2 py-0.5 rounded-full">
            -{Math.round(discount)}% OFF
          </span>
          {dynamicPrice?.reasons?.[0] && (
            <span className="text-slate-400 text-xs">{dynamicPrice.reasons[0]}</span>
          )}
        </div>
      )}

      {dynamicPrice && large && (
        <div className="flex gap-3 mt-2 flex-wrap">
          {[
            { label: 'Persona', val: dynamicPrice.persona_modifier },
            { label: 'Demand',  val: dynamicPrice.demand_modifier },
            { label: 'Stock',   val: dynamicPrice.inventory_modifier },
          ].map(({ label, val }) => val && (
            <div key={label} className="flex items-center gap-1 text-xs">
              <span className="text-slate-500">{label}:</span>
              <span className={`font-semibold ${(val - 1) < 0 ? 'text-emerald-400' : (val - 1) > 0 ? 'text-red-400' : 'text-slate-400'}`}>
                {(val - 1) >= 0 ? '+' : ''}{((val - 1) * 100).toFixed(1)}%
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
