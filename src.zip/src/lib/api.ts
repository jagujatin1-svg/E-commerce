const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export interface BehaviorEvent {
  session_id: string;
  event_type: 'page_view' | 'click' | 'hover' | 'scroll' | 'search' | 'cart_add' | 'cart_remove' | 'purchase' | 'compare' | 'wishlist';
  product_id?: string;
  category?: string;
  metadata?: Record<string, unknown>;
}

export async function sendEvent(event: BehaviorEvent): Promise<void> {
  try {
    await fetch(`${API_BASE}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(event),
    });
  } catch {
    // Silent fail — don't disrupt UX for analytics
  }
}

export async function getProducts(): Promise<Product[]> {
  const res = await fetch(`${API_BASE}/products`);
  const data = await res.json();
  return data.products;
}

export async function getProduct(id: string): Promise<Product> {
  const res = await fetch(`${API_BASE}/products/${id}`);
  return res.json();
}

export async function getRecommendations(sessionId: string): Promise<{ products: Product[]; persona: string; ui_mode: string }> {
  const res = await fetch(`${API_BASE}/recommendations/${sessionId}`);
  return res.json();
}

export async function getTrending(): Promise<{ products: Product[] }> {
  const res = await fetch(`${API_BASE}/recommendations/trending`);
  return res.json();
}

export async function getDeals(): Promise<{ products: Product[] }> {
  const res = await fetch(`${API_BASE}/recommendations/deals`);
  return res.json();
}

export async function getDynamicPrice(productId: string, sessionId: string) {
  try {
    const res = await fetch(`${API_BASE}/pricing/${productId}/${sessionId}`);
    return res.json();
  } catch {
    return null;
  }
}

export async function getBatchPrices(sessionId: string) {
  try {
    const res = await fetch(`${API_BASE}/pricing/batch/${sessionId}`);
    const data = await res.json();
    return data.prices as DynamicPriceResponse[];
  } catch {
    return [];
  }
}

export interface Product {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  base_price: number;
  inventory: number;
  rating: number;
  reviews: number;
  image: string;
  tags: string[];
  specs: Record<string, string>;
  demand_score: number;
}

export interface DynamicPriceResponse {
  product_id: string;
  session_id: string;
  base_price: number;
  final_price: number;
  discount_pct: number;
  multiplier: number;
  reasons: string[];
  persona_modifier: number;
  demand_modifier: number;
  inventory_modifier: number;
}
