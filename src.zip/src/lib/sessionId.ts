/**
 * Generates and persists a unique session ID in localStorage.
 * Falls back to a generated ID if localStorage is not available (SSR).
 */
let _sessionId: string | null = null;

export function getSessionId(): string {
  if (_sessionId) return _sessionId;

  if (typeof window === 'undefined') {
    _sessionId = `ssr-${Date.now()}`;
    return _sessionId;
  }

  const stored = localStorage.getItem('ecom_session_id');
  if (stored) {
    _sessionId = stored;
    return _sessionId;
  }

  const generated = `sess_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
  localStorage.setItem('ecom_session_id', generated);
  _sessionId = generated;
  return _sessionId;
}

export function resetSessionId(): void {
  _sessionId = null;
  if (typeof window !== 'undefined') {
    localStorage.removeItem('ecom_session_id');
  }
}
