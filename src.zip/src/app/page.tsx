'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { getProducts, getBatchPrices, Product } from '@/lib/api';
import { getSessionId } from '@/lib/sessionId';
import { usePersonaStore } from '@/store/personaStore';
import { useBehaviorTracker } from '@/hooks/useBehaviorTracker';
import { useWebSocket } from '@/hooks/useWebSocket';
import Navbar from '@/components/Navbar';
import ProductCard from '@/components/ProductCard';
import PersonaBadge from '@/components/PersonaBadge';
import RecommendationRail from '@/components/RecommendationRail';
import { Search, X, ArrowRight, Zap, ShieldCheck, Star, TrendingUp } from 'lucide-react';

const CATEGORIES = ['All', 'Electronics', 'Mobile Phones', 'Gaming', 'Photography', 'Wearables', 'Accessories', 'Fashion', 'Sports', 'Home', 'Beauty'];

const HERO_CONFIGS = {
  skimmer:    { headline: 'Trending Right', accent: 'Now', sub: 'Hottest picks, curated for speed shoppers.' },
  researcher: { headline: 'Explore in', accent: 'Depth', sub: 'Detailed specs and honest comparisons.' },
  hunter:     { headline: "Today's Best", accent: 'Deals', sub: 'Maximum value, minimum price — just for you.' },
  unknown:    { headline: 'Discover Your', accent: 'Perfect Pick', sub: 'AI-powered shopping that learns your style.' },
};

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [filtered, setFiltered] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState<'relevance'|'price_asc'|'price_desc'|'rating'>('relevance');

  const sessionId = getSessionId();
  const { setSessionId, updatePrice, priceMap, persona } = usePersonaStore();
  const { trackSearch } = useBehaviorTracker({ category });
  useWebSocket(sessionId);

  const hero = HERO_CONFIGS[persona] ?? HERO_CONFIGS.unknown;

  useEffect(() => { setSessionId(sessionId); }, [sessionId, setSessionId]);

  useEffect(() => {
    getProducts().then(data => { setProducts(data); setFiltered(data); }).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!products.length) return;
    const fetchPrices = async () => { const p = await getBatchPrices(sessionId); p.forEach(pr => updatePrice(pr)); };
    fetchPrices();
    const iv = setInterval(fetchPrices, 30000);
    return () => clearInterval(iv);
  }, [products, sessionId, updatePrice]);

  const applyFilters = useCallback(() => {
    let r = [...products];
    if (category !== 'All') r = r.filter(p => p.category === category);
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter(p => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q) || p.tags.some(t => t.toLowerCase().includes(q)));
    }
    if (sort === 'price_asc')  r.sort((a,b) => a.base_price - b.base_price);
    if (sort === 'price_desc') r.sort((a,b) => b.base_price - a.base_price);
    if (sort === 'rating')     r.sort((a,b) => b.rating - a.rating);
    setFiltered(r);
  }, [products, category, search, sort]);

  useEffect(() => { applyFilters(); }, [applyFilters]);

  const featuredProducts = products.filter(p => p.demand_score > 0.88).slice(0, 3);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />

      {/* ── Hero Section ─────────────────────────────── */}
      <section style={{ padding: '4rem 0 3rem' }}>
        <div className="max-container">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem', alignItems: 'center', minHeight: '56vh' }}>
            {/* Left: Text */}
            <div>
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
                background: 'var(--surface)', border: '1px solid var(--border)',
                borderRadius: 'var(--r-full)', padding: '0.35rem 1rem',
                fontSize: '0.75rem', fontWeight: 700, color: 'var(--accent)',
                marginBottom: '1.75rem', boxShadow: 'var(--shadow-sm)',
              }}>
                <Zap size={12} fill="currentColor" />
                AI Persona Engine Active
              </div>

              <h1 style={{ fontSize: 'clamp(2.8rem,5vw,4.2rem)', fontWeight: 900, lineHeight: 1.05, letterSpacing: '-0.03em', marginBottom: '1.25rem' }}>
                {hero.headline}<br />
                <span style={{ color: 'var(--accent)' }}>{hero.accent}</span>
              </h1>
              <p style={{ fontSize: '1.05rem', color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: '2rem', maxWidth: '420px' }}>
                {hero.sub} Prices adapt in real-time based on your unique shopping behavior.
              </p>

              <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', marginBottom: '3rem' }}>
                <Link href="/products">
                  <button className="btn-primary">
                    Shop Now <ArrowRight size={16} />
                  </button>
                </Link>
                <Link href="/immersive">
                  <button className="btn-outline">
                    ✦ 3D Experience
                  </button>
                </Link>
              </div>

              {/* Trust badges */}
              <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
                {[
                  { icon: <ShieldCheck size={14} />, text: '100% Secure Checkout' },
                  { icon: <Star size={14} fill="currentColor" />, text: '4.8★ Rated Platform' },
                  { icon: <TrendingUp size={14} />, text: 'AI Dynamic Pricing' },
                ].map(({ icon, text }) => (
                  <div key={text} style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-muted)' }}>
                    <span style={{ color: 'var(--accent)' }}>{icon}</span>
                    {text}
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Featured product cards stack */}
            <div style={{ position: 'relative', padding: '1.5rem' }}>
              {/* Background blob */}
              <div style={{
                position: 'absolute', inset: 0,
                background: 'radial-gradient(ellipse at 60% 40%, #c0ddf0 0%, transparent 70%)',
                borderRadius: 'var(--r-xl)',
              }} />

              <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
                {loading ? (
                  [0,1,2].map(i => <div key={i} className="skeleton" style={{ height: 90, borderRadius: 'var(--r-lg)' }} />)
                ) : featuredProducts.map((p, i) => {
                  const dp = priceMap[p.id];
                  const price = dp?.final_price ?? p.base_price;
                  const colors = ['#e8f3ff', '#e8f8f3', '#fff4ec'];
                  return (
                    <Link href={`/product/${p.id}`} key={p.id} style={{ textDecoration: 'none' }}>
                      <div
                        className={i === 0 ? 'float-card' : i === 1 ? 'float-card-delay' : ''}
                        style={{
                          background: 'var(--surface)', borderRadius: 'var(--r-lg)',
                          border: '1px solid var(--border-light)',
                          boxShadow: 'var(--shadow)',
                          display: 'flex', alignItems: 'center', gap: '1rem',
                          padding: '0.875rem 1rem', cursor: 'pointer',
                          transition: 'transform 0.2s, box-shadow 0.2s',
                        }}
                      >
                        <div style={{
                          width: 60, height: 60, borderRadius: 'var(--r-md)',
                          overflow: 'hidden', flexShrink: 0,
                          background: colors[i],
                        }}>
                          {p.image && <img src={p.image} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} referrerPolicy="no-referrer-when-downgrade" />}
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <p style={{ fontSize: '0.67rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 2 }}>{p.subcategory}</p>
                          <p style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</p>
                        </div>
                        <div style={{ textAlign: 'right', flexShrink: 0 }}>
                          <p style={{ fontSize: '1rem', fontWeight: 900, color: 'var(--text-primary)' }}>₹{Math.round(price).toLocaleString('en-IN')}</p>
                          {dp && dp.discount_pct > 0.5 && (
                            <span className="badge badge-sale" style={{ fontSize: '0.6rem' }}>-{Math.round(dp.discount_pct)}%</span>
                          )}
                        </div>
                      </div>
                    </Link>
                  );
                })}

                {/* Stats pill */}
                <div style={{ display: 'flex', gap: '0.75rem', marginTop: '0.5rem', justifyContent: 'center' }}>
                  {[['85+', 'Products'], ['4.8★', 'Rating'], ['Real-time', 'AI Pricing']].map(([val, lbl]) => (
                    <div key={lbl} className="stat-pill" style={{ textAlign: 'center' }}>
                      <div style={{ fontWeight: 900, fontSize: '0.875rem', color: 'var(--text-primary)' }}>{val}</div>
                      <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', fontWeight: 600 }}>{lbl}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Search + Filter ───────────────────────────── */}
      <section style={{ borderTop: '1px solid var(--border-light)', borderBottom: '1px solid var(--border-light)', background: 'rgba(255,255,255,0.5)', padding: '1.25rem 0' }}>
        <div className="max-container">
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap' }}>
            {/* Search */}
            <div style={{ position: 'relative', flex: 1, minWidth: '240px' }}>
              <Search size={16} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                className="input-base"
                style={{ paddingLeft: '2.75rem', paddingRight: search ? '2.5rem' : '1.25rem' }}
                placeholder="Search 85+ products..."
                value={search}
                onChange={e => { setSearch(e.target.value); if (e.target.value.length > 2) trackSearch(e.target.value); }}
              />
              {search && <button onClick={() => setSearch('')} style={{ position: 'absolute', right: '0.875rem', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}><X size={14} /></button>}
            </div>

            {/* Sort */}
            <select
              value={sort}
              onChange={e => setSort(e.target.value as typeof sort)}
              style={{ background: 'var(--surface)', border: '1.5px solid var(--border)', borderRadius: 'var(--r-full)', padding: '0.65rem 1rem', fontSize: '0.85rem', color: 'var(--text-primary)', cursor: 'pointer', outline: 'none', fontFamily: 'inherit', fontWeight: 600 }}
            >
              <option value="relevance">Sort: Relevance</option>
              <option value="price_asc">Price: Low → High</option>
              <option value="price_desc">Price: High → Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>

          {/* Category chips */}
          <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem', flexWrap: 'wrap' }}>
            {CATEGORIES.map(cat => (
              <button key={cat} className={`chip ${category === cat ? 'active' : ''}`} onClick={() => setCategory(cat)}>
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Main Content ──────────────────────────────── */}
      <main className="max-container" style={{ padding: '2.5rem 1.5rem 5rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', gap: '2rem', alignItems: 'start' }}>
          {/* Sidebar */}
          <aside style={{ position: 'sticky', top: '80px' }}>
            <PersonaBadge />

            {/* Category breakdown */}
            <div className="card" style={{ padding: '1.25rem', marginTop: '1rem' }}>
              <p style={{ fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: '0.875rem' }}>Browse</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                {CATEGORIES.slice(1).map(cat => {
                  const count = products.filter(p => p.category === cat).length;
                  const isActive = category === cat;
                  return (
                    <button
                      key={cat}
                      onClick={() => setCategory(cat)}
                      style={{
                        width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        padding: '0.5rem 0.75rem', borderRadius: 'var(--r-sm)', border: 'none',
                        background: isActive ? 'var(--accent)' : 'transparent',
                        color: isActive ? 'white' : 'var(--text-secondary)',
                        fontSize: '0.85rem', fontWeight: isActive ? 700 : 500,
                        cursor: 'pointer', textAlign: 'left',
                        transition: 'all 0.15s',
                      }}
                    >
                      <span>{cat}</span>
                      <span style={{ fontSize: '0.72rem', opacity: 0.7 }}>{count}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </aside>

          {/* Product area */}
          <div>
            {/* Recommendations — shown only when viewing 'All' */}
            {category === 'All' && (
              <>
                <RecommendationRail sessionId={sessionId} mode="personalized" />
                <div className="section-divider" style={{ margin: '2rem 0' }} />
                <RecommendationRail sessionId={sessionId} mode="trending" />
                <div className="section-divider" style={{ margin: '2rem 0' }} />
                <RecommendationRail sessionId={sessionId} mode="deals" />
                <div className="section-divider" style={{ margin: '2rem 0' }} />
              </>
            )}

            {/* Filtered results */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
              <div>
                <h2 style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-primary)' }}>
                  {category === 'All' ? 'All Products' : category}
                  <span style={{ fontSize: '0.85rem', fontWeight: 500, color: 'var(--text-muted)', marginLeft: '0.5rem' }}>({filtered.length})</span>
                </h2>
              </div>
              {category !== 'All' && (
                <button onClick={() => setCategory('All')} className="btn-ghost" style={{ fontSize: '0.78rem' }}>
                  <X size={12} /> Clear filter
                </button>
              )}
            </div>

            {loading ? (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1rem' }}>
                {[...Array(8)].map((_,i) => <div key={i} className="skeleton" style={{ height: 320 }} />)}
              </div>
            ) : filtered.length === 0 ? (
              <div className="card" style={{ padding: '4rem', textAlign: 'center' }}>
                <p style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>🔍</p>
                <p style={{ fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.5rem' }}>No products found</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Try a different search or category</p>
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1rem' }}>
                {filtered.map(product => (
                  <ProductCard key={product.id} product={product} dynamicPrice={priceMap[product.id] ?? null} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
