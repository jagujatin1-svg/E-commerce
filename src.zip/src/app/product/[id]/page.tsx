'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getProduct, Product } from '@/lib/api';
import { getSessionId } from '@/lib/sessionId';
import { usePersonaStore } from '@/store/personaStore';
import { useBehaviorTracker } from '@/hooks/useBehaviorTracker';
import Navbar from '@/components/Navbar';
import PriceTag from '@/components/PriceTag';
import {
  Star, ShoppingCart, ArrowLeft, Package,
  TrendingUp, Check, ChevronDown, ChevronUp
} from 'lucide-react';

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [specsOpen, setSpecsOpen] = useState(false);

  const sessionId = getSessionId();
  const { addToCart, removeFromCart, cartItems, priceMap, addToast } = usePersonaStore();
  const inCart = product ? cartItems.includes(product.id) : false;
  const { trackCartAdd, trackCartRemove } = useBehaviorTracker({
    productId: id,
    category: product?.category,
  });

  useEffect(() => {
    if (!id) return;
    const load = async () => {
      try {
        const data = await getProduct(id);
        setProduct(data);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  const handleCart = () => {
    if (!product) return;
    if (inCart) {
      removeFromCart(product.id);
      trackCartRemove(product.id);
      addToast('Removed from cart', 'info');
    } else {
      addToCart(product.id);
      trackCartAdd(product.id, product.category);
      addToast(`${product.name.slice(0, 32)}… added to cart! 🛒`, 'success');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="skeleton rounded-2xl h-80" />
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => <div key={i} className="skeleton rounded-lg h-8" style={{ width: `${80 - i * 12}%` }} />)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Navbar />
        <div className="text-center">
          <p className="text-6xl mb-4">😕</p>
          <p className="text-white text-xl font-bold">Product not found</p>
          <button onClick={() => router.back()} className="mt-4 text-[#6272f5] hover:underline">
            Go back
          </button>
        </div>
      </div>
    );
  }

  const dynamicPrice = priceMap[product.id] ?? null;
  const stockLevel = product.inventory < 10 ? 'low' : product.inventory < 30 ? 'medium' : 'high';

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="max-w-5xl mx-auto px-4 py-8" data-product-id={product.id} data-category={product.category}>
        {/* Breadcrumb */}
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 text-slate-400 hover:text-white text-sm mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to products
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {/* Image panel */}
          <div className="glass rounded-3xl overflow-hidden flex items-center justify-center relative" style={{ minHeight: '360px' }}>
            {product.image ? (
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
                style={{ minHeight: '360px', maxHeight: '420px' }}
                crossOrigin="anonymous"
                referrerPolicy="no-referrer-when-downgrade"
              />
            ) : (
              <div className="text-8xl opacity-60 hover:opacity-100 hover:scale-110 transition-all duration-500 p-12">
                {getCategoryEmoji(product.category)}
              </div>
            )}
            {/* Overlay gradient for non-image fallback feel */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
          </div>

          {/* Details panel */}
          <div className="flex flex-col">
            <div className="flex-1">
              {/* Category + badges */}
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <span className="text-xs text-slate-500 uppercase tracking-wider font-medium bg-white/5 px-2 py-1 rounded-lg">
                  {product.category}
                </span>
                <span className="text-xs text-slate-500 bg-white/5 px-2 py-1 rounded-lg">{product.subcategory}</span>
                {product.demand_score > 0.7 && (
                  <span className="flex items-center gap-1 text-xs bg-orange-500/20 border border-orange-500/30 text-orange-400 px-2 py-1 rounded-full">
                    <TrendingUp className="w-3 h-3" /> High Demand
                  </span>
                )}
              </div>

              <h1 className="text-white font-black text-2xl sm:text-3xl leading-tight mb-4">{product.name}</h1>

              {/* Rating */}
              <div className="flex items-center gap-3 mb-5">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`w-4 h-4 ${i < Math.round(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-slate-600'}`} />
                  ))}
                </div>
                <span className="text-slate-400 text-sm">{product.rating.toFixed(1)}</span>
                <span className="text-slate-500 text-sm">({product.reviews.toLocaleString('en-IN')} reviews)</span>
              </div>

              {/* Dynamic price */}
              <div className="mb-6">
                <PriceTag productId={product.id} basePrice={product.base_price} large />
              </div>

              {/* Inventory */}
              <div className="flex items-center gap-3 mb-6">
                <Package className="w-4 h-4 text-slate-400" />
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <span className="text-slate-400 text-xs">Stock</span>
                    <span className={`text-xs font-semibold ${
                      stockLevel === 'low' ? 'text-red-400' : stockLevel === 'medium' ? 'text-yellow-400' : 'text-emerald-400'
                    }`}>
                      {product.inventory} units {stockLevel === 'low' ? '— Low!' : ''}
                    </span>
                  </div>
                  <div className="confidence-bar">
                    <div
                      className="confidence-fill"
                      style={{
                        width: `${Math.min(100, (product.inventory / 100) * 100)}%`,
                        background: stockLevel === 'low' ? '#f87171' : stockLevel === 'medium' ? '#fbbf24' : '#34d399',
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 mb-6">
                {product.tags.map((tag) => (
                  <span key={tag} className="text-xs bg-white/5 border border-white/8 text-slate-400 px-2.5 py-1 rounded-full">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-3">
              <button
                onClick={handleCart}
                className={`w-full py-3.5 rounded-2xl font-bold text-base flex items-center justify-center gap-2 transition-all ${
                  inCart
                    ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-400'
                    : 'bg-[#6272f5] hover:bg-[#4240cf] text-white glow-brand'
                }`}
              >
                {inCart ? (
                  <><Check className="w-5 h-5" /> Added to Cart</>
                ) : (
                  <><ShoppingCart className="w-5 h-5" /> Add to Cart</>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Specs accordion */}
        {product.specs && Object.keys(product.specs).length > 0 && (
          <div className="glass rounded-2xl mt-8 border border-white/5 overflow-hidden">
            <button
              className="w-full flex items-center justify-between p-5 text-white font-semibold hover:bg-white/5 transition-colors"
              onClick={() => setSpecsOpen(!specsOpen)}
            >
              Technical Specifications
              {specsOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </button>
            {specsOpen && (
              <div className="border-t border-white/5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-0">
                  {Object.entries(product.specs).map(([key, value], i) => (
                    <div key={key} className={`flex gap-4 px-5 py-3 ${i % 2 === 0 ? 'bg-white/2' : ''}`}>
                      <span className="text-slate-500 text-sm min-w-[140px] font-medium">{key}</span>
                      <span className="text-slate-200 text-sm">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

function getCategoryEmoji(category: string): string {
  const map: Record<string, string> = {
    Electronics: '💻', Audio: '🎧', Gaming: '🎮', Photography: '📷',
    Wearables: '⌚', 'Mobile Phones': '📱', Accessories: '🔌',
    Health: '💊', Fashion: '👗', Sports: '🏋️', Books: '📚',
    Furniture: '🪑', Kitchen: '🍳', Toys: '🧸', Tools: '🔧',
  };
  return map[category] ?? '📦';
}
