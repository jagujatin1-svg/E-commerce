'use client';

import Link from 'next/link';
import { usePersonaStore } from '@/store/personaStore';
import { getProduct, Product } from '@/lib/api';
import Navbar from '@/components/Navbar';
import { Heart, ShoppingCart, ArrowLeft, Trash2, Tag } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function WishlistPage() {
  const { wishlistItems, toggleWishlist, addToCart, cartItems, priceMap, addToast } = usePersonaStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!wishlistItems.length) { setProducts([]); setLoading(false); return; }
      const fetched = await Promise.all(wishlistItems.map((id) => getProduct(id).catch(() => null)));
      setProducts(fetched.filter(Boolean) as Product[]);
      setLoading(false);
    };
    load();
  }, [wishlistItems]);

  const handleMoveToCart = (productId: string, name: string) => {
    addToCart(productId);
    toggleWishlist(productId);
    addToast(`${name.slice(0, 30)}… moved to cart 🛒`, 'success');
  };

  const handleRemove = (productId: string) => {
    toggleWishlist(productId);
    addToast('Removed from wishlist', 'info');
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <main style={{ maxWidth: '960px', margin: '0 auto', padding: '2.5rem 1.5rem 5rem' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
          <Link href="/products">
            <button className="btn-ghost" style={{ padding: '0.5rem 0.875rem' }}>
              <ArrowLeft size={16} /> Browse Products
            </button>
          </Link>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Heart size={22} fill="var(--rose)" color="var(--rose)" />
            <h1 style={{ fontWeight: 900, fontSize: '1.5rem', color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
              Wishlist
            </h1>
            {wishlistItems.length > 0 && (
              <span style={{
                background: 'var(--rose)', color: 'white',
                fontSize: '0.72rem', fontWeight: 800,
                padding: '0.2rem 0.6rem', borderRadius: 'var(--r-full)',
              }}>
                {wishlistItems.length}
              </span>
            )}
          </div>
        </div>

        {loading ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1rem' }}>
            {[...Array(4)].map((_, i) => <div key={i} className="skeleton" style={{ height: 340, borderRadius: 'var(--r-lg)' }} />)}
          </div>
        ) : wishlistItems.length === 0 ? (
          <div className="card" style={{ padding: '5rem', textAlign: 'center' }}>
            <p style={{ fontSize: '3rem', marginBottom: '1rem' }}>💝</p>
            <h2 style={{ fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.5rem' }}>Your wishlist is empty</h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: '2rem' }}>
              Save products you love and come back to them later
            </p>
            <Link href="/products">
              <button className="btn-primary">Browse Products</button>
            </Link>
          </div>
        ) : (
          <>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: '1.25rem' }}>
              {wishlistItems.length} saved item{wishlistItems.length !== 1 ? 's' : ''} · Prices updated in real-time
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1rem' }}>
              {products.map((product) => {
                const dp = priceMap[product.id];
                const price = dp?.final_price ?? product.base_price;
                const hasDiscount = (dp?.discount_pct ?? 0) > 0.5;
                const inCart = cartItems.includes(product.id);

                return (
                  <div key={product.id} className="card" style={{ overflow: 'hidden' }}>
                    {/* Image */}
                    <Link href={`/product/${product.id}`}>
                      <div className="product-img" style={{ height: 200, position: 'relative', display: 'block' }}>
                        {product.image ? (
                          <img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} referrerPolicy="no-referrer-when-downgrade" />
                        ) : (
                          <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '3rem', background: 'var(--surface-2)' }}>
                            {getCategoryEmoji(product.category)}
                          </div>
                        )}
                        {hasDiscount && dp && (
                          <div style={{
                            position: 'absolute', top: '0.75rem', left: '0.75rem',
                            background: 'var(--rose)', color: 'white',
                            fontSize: '0.68rem', fontWeight: 800,
                            padding: '0.2rem 0.6rem', borderRadius: 'var(--r-full)',
                          }}>
                            -{Math.abs(Math.round(dp.discount_pct))}% OFF
                          </div>
                        )}
                      </div>
                    </Link>

                    <div style={{ padding: '1rem' }}>
                      <p style={{ fontSize: '0.68rem', fontWeight: 700, color: 'var(--text-muted)', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '0.25rem' }}>{product.category}</p>
                      <Link href={`/product/${product.id}`}>
                        <h3 style={{ fontWeight: 700, fontSize: '0.875rem', color: 'var(--text-primary)', marginBottom: '0.625rem', lineHeight: 1.4 }} className="line-clamp-2">
                          {product.name}
                        </h3>
                      </Link>

                      {/* Price */}
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.5rem', marginBottom: '0.875rem' }}>
                        <span style={{ fontWeight: 900, fontSize: '1.1rem', color: 'var(--text-primary)' }}>
                          ₹{Math.round(price).toLocaleString('en-IN')}
                        </span>
                        {hasDiscount && (
                          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textDecoration: 'line-through' }}>
                            ₹{product.base_price.toLocaleString('en-IN')}
                          </span>
                        )}
                      </div>

                      {/* AI reason */}
                      {dp?.reasons[0] && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', marginBottom: '0.875rem' }}>
                          <Tag size={11} color="var(--mint)" />
                          <p style={{ fontSize: '0.68rem', color: 'var(--mint)', fontWeight: 600 }}>{dp.reasons[0]}</p>
                        </div>
                      )}

                      {/* Actions */}
                      <div style={{ display: 'flex', gap: '0.5rem' }}>
                        <button
                          onClick={() => handleMoveToCart(product.id, product.name)}
                          disabled={inCart}
                          style={{
                            flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.375rem',
                            padding: '0.625rem', borderRadius: 'var(--r-sm)',
                            background: inCart ? 'var(--mint-bg)' : 'var(--text-primary)',
                            color: inCart ? 'var(--mint)' : 'white',
                            border: 'none', cursor: inCart ? 'default' : 'pointer',
                            fontWeight: 700, fontSize: '0.8rem',
                            transition: 'all 0.2s',
                          }}
                        >
                          <ShoppingCart size={14} />
                          {inCart ? 'In Cart' : 'Add to Cart'}
                        </button>
                        <button
                          onClick={() => handleRemove(product.id)}
                          style={{
                            width: 38, height: 38,
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            background: 'var(--rose-bg)', border: '1px solid var(--border-light)',
                            borderRadius: 'var(--r-sm)', cursor: 'pointer',
                            color: 'var(--rose)', transition: 'all 0.2s',
                          }}
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </main>
    </div>
  );
}

function getCategoryEmoji(category: string): string {
  const map: Record<string, string> = {
    Electronics: '💻', Gaming: '🎮', Photography: '📷',
    Wearables: '⌚', 'Mobile Phones': '📱', Accessories: '🔌',
    Fashion: '👗', Sports: '🏋️', Home: '🏠', Beauty: '✨',
  };
  return map[category] ?? '📦';
}
