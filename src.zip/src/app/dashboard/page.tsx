'use client';

import { useEffect } from 'react';
import { getSessionId } from '@/lib/sessionId';
import { usePersonaStore } from '@/store/personaStore';
import { useBehaviorTracker } from '@/hooks/useBehaviorTracker';
import { useWebSocket } from '@/hooks/useWebSocket';
import Navbar from '@/components/Navbar';
import BehaviorDashboard from '@/components/BehaviorDashboard';
import PersonaBadge from '@/components/PersonaBadge';
import { LayoutDashboard } from 'lucide-react';

export default function DashboardPage() {
  const sessionId = getSessionId();
  const { setSessionId } = usePersonaStore();
  useBehaviorTracker();
  useWebSocket(sessionId);

  useEffect(() => {
    setSessionId(sessionId);
  }, [sessionId, setSessionId]);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="max-w-5xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6272f5] to-[#a78bfa] flex items-center justify-center">
            <LayoutDashboard className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-white font-black text-2xl">Behavior Dashboard</h1>
            <p className="text-slate-400 text-sm">Real-time AI analysis of your shopping persona</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main dashboard */}
          <div className="lg:col-span-2">
            <BehaviorDashboard />
          </div>

          {/* Persona card */}
          <div className="space-y-6">
            <PersonaBadge />

            {/* Session info */}
            <div className="glass rounded-2xl p-5 border border-white/5">
              <h3 className="text-white font-semibold mb-3 text-sm">Session Info</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500 text-xs">Session ID</span>
                  <span className="text-slate-300 text-xs font-mono">{sessionId.slice(0, 16)}…</span>
                </div>
              </div>
            </div>

            {/* How it works */}
            <div className="glass rounded-2xl p-5 border border-white/5">
              <h3 className="text-white font-semibold mb-3 text-sm">How It Works</h3>
              <div className="space-y-3 text-xs text-slate-400">
                {[
                  { icon: '👀', text: 'We track hover time, scroll speed, and click patterns' },
                  { icon: '🧠', text: 'Our AI classifies you into a Shadow Persona in real-time' },
                  { icon: '💰', text: 'Prices adapt based on demand, inventory, and your persona' },
                  { icon: '🎯', text: 'Recommendations personalise to your shopping style' },
                ].map(({ icon, text }) => (
                  <div key={icon} className="flex gap-2">
                    <span>{icon}</span>
                    <p>{text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
