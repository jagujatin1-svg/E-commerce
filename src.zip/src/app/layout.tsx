import type { Metadata } from 'next';
import './globals.css';
import ToastContainer from '@/components/ToastContainer';

export const metadata: Metadata = {
  title: 'NexShop — AI-Powered Shopping Experience',
  description: 'Real-time personalized e-commerce with AI-driven pricing, shadow persona detection, and intelligent recommendations.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        <ToastContainer />
      </body>
    </html>
  );
}
