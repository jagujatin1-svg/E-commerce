'use client';

import { useEffect, useState, useCallback } from 'react';
import { getProducts, getBatchPrices, Product } from '@/lib/api';
import { getSessionId } from '@/lib/sessionId';
import { usePersonaStore } from '@/store/personaStore';
import { useBehaviorTracker } from '@/hooks/useBehaviorTracker';
import { useWebSocket } from '@/hooks/useWebSocket';
import Navbar from '@/components/Navbar';
import ProductCard from '@/components/ProductCard';
import { Search, X, Grid3X3, List, SlidersHorizontal } from 'lucide-react';

const CATEGORIES = ['All', 'Electronics', 'Mobile Phones', 'Gaming', 'Photography', 'Wearables', 'Accessories', 'Fashion', 'Sports', 'Home', 'Beauty'];

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [filtered, setFiltered] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState<'relevance' | 'price_asc' | 'price_desc' | 'rating'>('relevance');
  const [view, setView] = useState<'grid' | 'list'>('grid');

  const sessionId = getSessionId();
  const { setSessionId, updatePrice, priceMap } = usePersonaStore();
  const { trackSearch } = useBehaviorTracker({ category });
  useWebSocket(sessionId);

  useEffect(() => { setSessionId(sessionId); }, [sessionId, setSessionId]);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await getProducts();
        setProducts(data);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  useEffect(() => {
    if (!products.length) return;
    const fetch = async () => {
      const prices = await getBatchPrices(sessionId);
      prices.forEach((p) => updatePrice(p));
    };
    fetch();
  }, [products, sessionId, updatePrice]);

  const applyFilters = useCallback(() => {
    let result = [...products];
    if (category !== 'All') result = result.filter((p) => p.category === category);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter((p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    if (sort === 'price_asc') result.sort((a, b) => a.base_price - b.base_price);
    if (sort === 'price_desc') result.sort((a, b) => b.base_price - a.base_price);
    if (sort === 'rating') result.sort((a, b) => b.rating - a.rating);
    setFiltered(result);
  }, [products, category, search, sort]);

  useEffect(() => { applyFilters(); }, [applyFilters]);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <main style={{ maxWidth: '1280px', margin: '0 auto', padding: '2rem 1.5rem 5rem' }}>
        {/* Header */}
        <div style={{ marginBottom: '1.5rem' }}>
          <h1 style={{ color: 'var(--text-primary)', fontWeight: 900, fontSize: '1.75rem', marginBottom: '0.25rem', letterSpacing: '-0.02em' }}>
            All Products
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            Browse our full catalog — prices adapt to your persona in real-time
          </p>
        </div>

        {/* Filters bar */}
        <div className="card" style={{ padding: '0.875rem 1.25rem', marginBottom: '1rem', display: 'flex', flexWrap: 'wrap', gap: '0.75rem', alignItems: 'center' }}>
          {/* Search */}
          <div style={{ position: 'relative', flex: '1', minWidth: '180px' }}>
            <Search style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', width: 15, height: 15, color: 'var(--text-muted)' }} />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                if (e.target.value.length > 2) trackSearch(e.target.value);
              }}
              placeholder="Search 85+ products…"
              className="input-base"
              style={{ paddingLeft: '2.25rem', paddingRight: search ? '2rem' : '0.875rem', borderRadius: 'var(--r-full)' }}
            />
            {search && (
              <button onClick={() => setSearch('')} style={{ position: 'absolute', right: '0.75rem', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', display: 'flex', padding: 0 }}>
                <X style={{ width: 14, height: 14, color: 'var(--text-muted)' }} />
              </button>
            )}
          </div>

          {/* Sort */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem' }}>
            <SlidersHorizontal size={14} color="var(--text-muted)" />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as typeof sort)}
              style={{
                background: 'var(--surface)', border: '1px solid var(--border)',
                borderRadius: 'var(--r-sm)', padding: '0.5rem 0.75rem',
                color: 'var(--text-secondary)', fontSize: '0.825rem',
                fontWeight: 600, cursor: 'pointer',
              }}
            >
              <option value="relevance">Relevance</option>
              <option value="price_asc">Price: Low → High</option>
              <option value="price_desc">Price: High → Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>

          {/* View toggle */}
          <div style={{ display: 'flex', background: 'var(--surface-2)', borderRadius: 'var(--r-sm)', overflow: 'hidden', border: '1px solid var(--border-light)' }}>
            <button
              onClick={() => setView('grid')}
              style={{
                padding: '0.5rem 0.75rem', border: 'none', cursor: 'pointer',
                background: view === 'grid' ? 'var(--text-primary)' : 'transparent',
                color: view === 'grid' ? 'white' : 'var(--text-muted)',
                display: 'flex', alignItems: 'center', transition: 'all 0.15s',
              }}
            >
              <Grid3X3 style={{ width: 15, height: 15 }} />
            </button>
            <button
              onClick={() => setView('list')}
              style={{
                padding: '0.5rem 0.75rem', border: 'none', cursor: 'pointer',
                background: view === 'list' ? 'var(--text-primary)' : 'transparent',
                color: view === 'list' ? 'white' : 'var(--text-muted)',
                display: 'flex', alignItems: 'center', transition: 'all 0.15s',
              }}
            >
              <List style={{ width: 15, height: 15 }} />
            </button>
          </div>
        </div>

        {/* Category chips */}
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              style={{
                padding: '0.375rem 1rem', borderRadius: 'var(--r-full)',
                fontSize: '0.825rem', fontWeight: 600, cursor: 'pointer',
                border: '1px solid var(--border)',
                background: category === cat ? 'var(--text-primary)' : 'var(--surface)',
                color: category === cat ? 'white' : 'var(--text-secondary)',
                transition: 'all 0.15s',
                boxShadow: category === cat ? 'var(--shadow-sm)' : 'none',
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results count */}
        <p style={{ color: 'var(--text-muted)', fontSize: '0.825rem', marginBottom: '1rem' }}>
          Showing <strong style={{ color: 'var(--text-primary)' }}>{filtered.length}</strong> products
        </p>

        {/* Products */}
        {loading ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1rem' }}>
            {[...Array(12)].map((_, i) => <div key={i} className="skeleton" style={{ borderRadius: 'var(--r-lg)', height: '320px' }} />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="card" style={{ padding: '5rem', textAlign: 'center' }}>
            <p style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>🔍</p>
            <p style={{ color: 'var(--text-primary)', fontWeight: 800, fontSize: '1.1rem' }}>No products found</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: '0.375rem' }}>Try different filters or search terms</p>
          </div>
        ) : view === 'grid' ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1rem' }}>
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} dynamicPrice={priceMap[product.id] ?? null} />
            ))}
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} dynamicPrice={priceMap[product.id] ?? null} compact />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
