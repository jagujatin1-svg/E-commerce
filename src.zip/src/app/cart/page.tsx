'use client';

import Link from 'next/link';
import { usePersonaStore } from '@/store/personaStore';
import { useBehaviorTracker } from '@/hooks/useBehaviorTracker';
import Navbar from '@/components/Navbar';
import { ShoppingCart, Trash2, ArrowLeft, ShoppingBag, ArrowRight, Tag } from 'lucide-react';
import { getProduct, Product } from '@/lib/api';
import { useEffect, useState } from 'react';

export default function CartPage() {
  const { cartItems, removeFromCart, priceMap, addToast } = usePersonaStore();
  const [products, setProducts] = useState<Product[]>([]);
  const { trackCartRemove } = useBehaviorTracker();

  useEffect(() => {
    const load = async () => {
      const fetched = await Promise.all(cartItems.map((id) => getProduct(id).catch(() => null)));
      setProducts(fetched.filter(Boolean) as Product[]);
    };
    if (cartItems.length > 0) load();
    else setProducts([]);
  }, [cartItems]);

  const handleRemove = (productId: string, name: string) => {
    removeFromCart(productId);
    trackCartRemove(productId);
    addToast(`${name.slice(0, 30)}… removed from cart`, 'info');
  };

  const total = products.reduce((sum, p) => {
    const price = priceMap[p.id]?.final_price ?? p.base_price;
    return sum + price;
  }, 0);

  const savings = products.reduce((sum, p) => {
    const dynamic = priceMap[p.id];
    if (dynamic && dynamic.discount_pct > 0.5) {
      return sum + (p.base_price - dynamic.final_price);
    }
    return sum;
  }, 0);

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <main style={{ maxWidth: '960px', margin: '0 auto', padding: '2.5rem 1.5rem 5rem' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
          <Link href="/">
            <button className="btn-ghost" style={{ padding: '0.5rem 0.875rem' }}>
              <ArrowLeft size={16} /> Continue Shopping
            </button>
          </Link>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <ShoppingCart size={22} color="var(--accent)" />
            <h1 style={{ fontWeight: 900, fontSize: '1.5rem', color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
              Your Cart
            </h1>
            {cartItems.length > 0 && (
              <span style={{
                background: 'var(--accent)', color: 'white',
                fontSize: '0.72rem', fontWeight: 800,
                padding: '0.2rem 0.6rem', borderRadius: 'var(--r-full)',
              }}>
                {cartItems.length}
              </span>
            )}
          </div>
        </div>

        {cartItems.length === 0 ? (
          <div className="card" style={{ padding: '5rem', textAlign: 'center' }}>
            <p style={{ fontSize: '3rem', marginBottom: '1rem' }}>🛒</p>
            <h2 style={{ fontWeight: 800, color: 'var(--text-primary)', marginBottom: '0.5rem' }}>Your cart is empty</h2>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: '2rem' }}>
              Start browsing to find your perfect products
            </p>
            <Link href="/products">
              <button className="btn-primary">
                <ShoppingBag size={16} /> Browse Products
              </button>
            </Link>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: '1.5rem', alignItems: 'start' }}>
            {/* Items */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {products.map((product) => {
                const dp = priceMap[product.id];
                const price = dp?.final_price ?? product.base_price;
                const hasDiscount = (dp?.discount_pct ?? 0) > 0.5;

                return (
                  <div key={product.id} className="card" style={{ padding: '1rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    {/* Image */}
                    <div style={{ width: 70, height: 70, borderRadius: 'var(--r-md)', overflow: 'hidden', flexShrink: 0, background: 'var(--surface-2)' }}>
                      {product.image ? (
                        <img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                          referrerPolicy="no-referrer-when-downgrade" />
                      ) : (
                        <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.75rem' }}>
                          {getCategoryEmoji(product.category)}
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <Link href={`/product/${product.id}`} style={{ textDecoration: 'none' }}>
                        <p style={{ fontWeight: 700, color: 'var(--text-primary)', fontSize: '0.9rem', marginBottom: '0.125rem' }} className="line-clamp-1">
                          {product.name}
                        </p>
                      </Link>
                      <p style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>{product.category} · {product.subcategory}</p>
                      {hasDiscount && dp && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', marginTop: '0.25rem' }}>
                          <Tag size={11} color="var(--mint)" />
                          <p style={{ fontSize: '0.68rem', color: 'var(--mint)', fontWeight: 600 }}>{dp.reasons[0]}</p>
                        </div>
                      )}
                    </div>

                    {/* Price */}
                    <div style={{ textAlign: 'right', flexShrink: 0 }}>
                      <p style={{ fontWeight: 900, fontSize: '1rem', color: 'var(--text-primary)' }}>₹{Math.round(price).toLocaleString('en-IN')}</p>
                      {hasDiscount && (
                        <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textDecoration: 'line-through' }}>₹{product.base_price.toLocaleString('en-IN')}</p>
                      )}
                    </div>

                    {/* Remove */}
                    <button
                      onClick={() => handleRemove(product.id, product.name)}
                      style={{
                        width: 36, height: 36,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        background: 'var(--rose-bg)', border: '1px solid var(--border-light)',
                        borderRadius: 'var(--r-sm)', cursor: 'pointer',
                        color: 'var(--rose)', flexShrink: 0, transition: 'all 0.2s',
                      }}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Order summary */}
            <div style={{ position: 'sticky', top: '80px' }}>
              <div className="card" style={{ padding: '1.5rem' }}>
                <h2 style={{ fontWeight: 800, fontSize: '1rem', color: 'var(--text-primary)', marginBottom: '1.25rem' }}>Order Summary</h2>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem', marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Subtotal ({products.length} item{products.length !== 1 ? 's' : ''})</span>
                    <span style={{ fontWeight: 700, color: 'var(--text-primary)', fontSize: '0.875rem' }}>₹{Math.round(total).toLocaleString('en-IN')}</span>
                  </div>
                  {savings > 0.01 && (
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: 'var(--mint)', fontSize: '0.875rem' }}>🤖 AI Savings</span>
                      <span style={{ fontWeight: 700, color: 'var(--mint)', fontSize: '0.875rem' }}>-₹{Math.round(savings).toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Shipping</span>
                    <span style={{ fontWeight: 700, color: 'var(--mint)', fontSize: '0.875rem' }}>Free</span>
                  </div>
                </div>

                <div className="section-divider" style={{ marginBottom: '1rem' }} />

                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
                  <span style={{ fontWeight: 800, color: 'var(--text-primary)', fontSize: '1.05rem' }}>Total</span>
                  <span style={{ fontWeight: 900, fontSize: '1.25rem', color: 'var(--text-primary)' }}>₹{Math.round(total).toLocaleString('en-IN')}</span>
                </div>

                <Link href="/checkout" style={{ display: 'block' }}>
                  <button className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '1rem', fontSize: '1rem' }}>
                    Proceed to Checkout <ArrowRight size={16} />
                  </button>
                </Link>

                {savings > 0.01 && (
                  <p style={{ color: 'var(--mint)', fontSize: '0.75rem', textAlign: 'center', marginTop: '0.875rem', fontWeight: 600 }}>
                    🎉 You saved ₹{Math.round(savings).toLocaleString('en-IN')} with AI pricing!
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function getCategoryEmoji(category: string): string {
  const map: Record<string, string> = {
    Electronics: '💻', Audio: '🎧', Gaming: '🎮', Photography: '📷',
    Wearables: '⌚', 'Mobile Phones': '📱', Accessories: '🔌',
    Fashion: '👗', Sports: '🏋️', Home: '🏠', Beauty: '✨',
  };
  return map[category] ?? '📦';
}
