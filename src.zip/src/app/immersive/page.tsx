'use client';

/**
 * ImmersiveView — The full 3D experience page.
 * Integrates all 3D components with real-time backend data.
 * Includes:
 *  - 2D/3D toggle
 *  - View mode switcher (showcase / cluster / path)
 *  - Live persona + price updates via existing WebSocket
 *  - Graceful degradation to 2D on low FPS
 *  - Behavior event recording for BehaviorPath3D
 */
import React, { useEffect, useState, useCallback, useRef, Suspense, lazy } from 'react';
import { useRouter } from 'next/navigation';
import { getRecommendations, getBatchPrices, Product } from '@/lib/api';
import { getSessionId } from '@/lib/sessionId';
import { usePersonaStore } from '@/store/personaStore';
import { useWebSocket } from '@/hooks/useWebSocket';
import Navbar from '@/components/Navbar';
import PersonaBadge from '@/components/PersonaBadge';
import PerfMonitor from '@/components/3d/PerfMonitor';
import { BehaviorNode, SceneView } from '@/components/3d/Scene3D';
import { Layers, Grid3X3, Network, GitBranch, ChevronRight, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Lazy-load the heavy R3F scene for code splitting
const Scene3D = lazy(() => import('@/components/3d/Scene3D'));

type UIMode = '3d' | '2d';

const VIEW_OPTIONS: { key: SceneView; label: string; icon: React.ReactNode; desc: string }[] = [
  { key: 'showcase', label: 'Showcase', icon: <Grid3X3 className="w-4 h-4" />, desc: 'Persona-adaptive product layout' },
  { key: 'cluster',  label: 'Cluster',  icon: <Network className="w-4 h-4" />,   desc: 'Orbiting recommendations' },
  { key: 'path',     label: 'Journey',  icon: <GitBranch className="w-4 h-4" />, desc: 'Your behavioral path' },
];

export default function ImmersiveViewPage() {
  const router = useRouter();
  const sessionId = getSessionId();
  const { setSessionId, persona, priceMap, updatePrice, isConnected } = usePersonaStore();
  useWebSocket(sessionId);

  const [products, setProducts] = useState<Product[]>([]);
  const [uiMode, setUiMode] = useState<UIMode>('3d');
  const [sceneView, setSceneView] = useState<SceneView>('showcase');
  const [behaviorNodes, setBehaviorNodes] = useState<BehaviorNode[]>([]);
  const [wsLatency, setWsLatency] = useState<number>(0);
  const [is3DSupported, setIs3DSupported] = useState(true);
  const pingTime = useRef<number>(0);

  useEffect(() => { setSessionId(sessionId); }, [sessionId, setSessionId]);

  // Detect WebGL support for graceful degradation
  useEffect(() => {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      setIs3DSupported(!!gl);
    } catch {
      setIs3DSupported(false);
    }
  }, []);

  // Load personalized recommendations
  useEffect(() => {
    const load = async () => {
      try {
        const data = await getRecommendations(sessionId);
        setProducts(data.products ?? []);
      } catch {
        setProducts([]);
      }
    };
    load();
  }, [sessionId, persona]);

  // Batch price refresh
  useEffect(() => {
    if (!products.length) return;
    const fetch = async () => {
      const prices = await getBatchPrices(sessionId);
      prices.forEach((p) => updatePrice(p));
    };
    fetch();
    const iv = setInterval(fetch, 20000);
    return () => clearInterval(iv);
  }, [products, sessionId, updatePrice]);

  // Track behavior events for 3D path
  const recordEvent = useCallback((type: BehaviorNode['type'], productId?: string) => {
    setBehaviorNodes(prev => [
      ...prev.slice(-50),
      { id: `${Date.now()}-${Math.random()}`, type, timestamp: Date.now(), productId },
    ]);
  }, []);

  // Listen for DOM events to populate path
  useEffect(() => {
    const onClick = () => recordEvent('click');
    const onScroll = () => recordEvent('scroll');
    document.addEventListener('click', onClick);
    window.addEventListener('scroll', onScroll, { passive: true });
    recordEvent('page_view');
    return () => {
      document.removeEventListener('click', onClick);
      window.removeEventListener('scroll', onScroll);
    };
  }, [recordEvent]);

  const handleSelectProduct = (product: Product) => {
    recordEvent('click', product.id);
    router.push(`/product/${product.id}`);
  };

  const handleLowFPS = useCallback((fps: number) => {
    if (fps < 20) setUiMode('2d');
  }, []);

  // Persona-aware label
  const PERSONA_LABEL = {
    skimmer: '⚡ Skimmer Mode — Fast curated picks',
    researcher: '🔬 Research Mode — Detailed product explorer',
    hunter: '🎯 Hunter Mode — Best deals spotlight',
    unknown: '👤 Building your profile…',
  }[persona];

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Layers className="w-5 h-5 text-[#6272f5]" />
              <h1 className="text-white font-black text-2xl">Immersive Experience</h1>
              {is3DSupported && (
                <span className="text-xs bg-[#6272f5]/20 border border-[#6272f5]/30 text-[#6272f5] px-2 py-0.5 rounded-full font-semibold">
                  3D LIVE
                </span>
              )}
            </div>
            <p className="text-slate-400 text-sm">{PERSONA_LABEL}</p>
          </div>

          {/* 2D / 3D Toggle */}
          {is3DSupported && (
            <div className="flex glass rounded-2xl overflow-hidden border border-white/5 self-start">
              {(['3d', '2d'] as UIMode[]).map((m) => (
                <button
                  key={m}
                  onClick={() => setUiMode(m)}
                  className={`px-5 py-2.5 text-sm font-bold transition-all ${
                    uiMode === m
                      ? 'bg-[#6272f5] text-white glow-brand'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {m.toUpperCase()}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar controls */}
          <aside className="lg:col-span-1 space-y-4">
            <PersonaBadge />

            {/* View mode switcher */}
            {(uiMode === '3d' && is3DSupported) && (
              <div className="glass rounded-2xl p-4 border border-white/5">
                <p className="text-slate-500 text-xs uppercase tracking-wider mb-3 font-semibold">Scene View</p>
                <div className="space-y-1">
                  {VIEW_OPTIONS.map(({ key, label, icon, desc }) => (
                    <button
                      key={key}
                      onClick={() => setSceneView(key)}
                      className={`w-full text-left p-3 rounded-xl transition-all flex items-center gap-3 ${
                        sceneView === key
                          ? 'bg-[#6272f5]/20 border border-[#6272f5]/30'
                          : 'hover:bg-white/5 border border-transparent'
                      }`}
                    >
                      <span className={sceneView === key ? 'text-[#6272f5]' : 'text-slate-400'}>{icon}</span>
                      <div>
                        <p className={`text-sm font-semibold ${sceneView === key ? 'text-white' : 'text-slate-300'}`}>
                          {label}
                        </p>
                        <p className="text-slate-500 text-xs">{desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quick stats */}
            <div className="glass rounded-2xl p-4 border border-white/5">
              <p className="text-slate-500 text-xs uppercase tracking-wider mb-3 font-semibold">Live Stats</p>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Products loaded</span>
                  <span className="text-white font-bold">{products.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Events tracked</span>
                  <span className="text-white font-bold">{behaviorNodes.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Prices synced</span>
                  <span className="text-emerald-400 font-bold">{Object.keys(priceMap).length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">WS Status</span>
                  <span className={`font-bold ${isConnected ? 'text-emerald-400' : 'text-slate-500'}`}>
                    {isConnected ? '● Live' : '○ Connecting'}
                  </span>
                </div>
              </div>
            </div>

            {/* Browse 2D CTA */}
            <a href="/" className="flex items-center justify-between glass rounded-2xl p-4 border border-white/5 hover:border-[#6272f5]/30 transition-colors group">
              <span className="text-slate-300 text-sm font-medium">Browse 2D Store</span>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-[#6272f5] transition-colors" />
            </a>
          </aside>

          {/* Main 3D / 2D canvas area */}
          <div className="lg:col-span-3">
            <AnimatePresence mode="wait">
              {uiMode === '3d' && is3DSupported ? (
                <motion.div
                  key="3d"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.4 }}
                  className="relative rounded-3xl overflow-hidden border border-white/8"
                  style={{
                    background: 'radial-gradient(ellipse at 50% 30%, #0b0b18 0%, #050508 100%)',
                    height: '620px',
                  } as React.CSSProperties}
                >
                  {/* Scene label */}
                  <div className="absolute top-4 left-4 z-10 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-white text-xs font-semibold glass px-3 py-1 rounded-full border border-white/10">
                      {VIEW_OPTIONS.find(v => v.key === sceneView)?.label} · {persona}
                    </span>
                  </div>

                  {/* Controls hint */}
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 text-slate-500 text-xs hidden sm:block">
                    Drag to orbit · Scroll to zoom · Click products to view
                  </div>

                  <Suspense fallback={
                    <div className="w-full h-full flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-12 h-12 border-2 border-[#6272f5] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                        <p className="text-slate-400 text-sm">Loading 3D scene…</p>
                      </div>
                    </div>
                  }>
                    <Scene3D
                      products={products}
                      persona={persona}
                      priceMap={priceMap as any}
                      behaviorNodes={behaviorNodes}
                      view={sceneView}
                      onSelectProduct={handleSelectProduct}
                    />
                  </Suspense>
                </motion.div>
              ) : (
                <motion.div
                  key="2d"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* 2D fallback grid */}
                  {!is3DSupported && (
                    <div className="glass rounded-xl p-3 mb-4 border border-yellow-500/30 text-yellow-400 text-sm flex items-center gap-2">
                      <Zap className="w-4 h-4 flex-shrink-0" />
                      WebGL not available — showing 2D mode
                    </div>
                  )}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {products.map((product) => {
                      const dp = priceMap[product.id];
                      const price = dp?.final_price ?? product.base_price;
                      return (
                        <a
                          key={product.id}
                          href={`/product/${product.id}`}
                          className="glass glass-hover shimmer rounded-2xl p-5 flex flex-col"
                          data-product-id={product.id}
                        >
                          {/* Product image or emoji */}
                          <div className="h-28 mb-3 rounded-xl overflow-hidden bg-gradient-to-br from-[#12121f] to-[#1a1a2e] flex items-center justify-center">
                            {product.image ? (
                              <img src={product.image} alt={product.name} className="w-full h-full object-cover"
                                referrerPolicy="no-referrer-when-downgrade" />
                            ) : (
                              <div className="text-5xl">{getCategoryEmoji(product.category)}</div>
                            )}
                          </div>
                          <h3 className="text-white font-semibold text-sm mb-1 line-clamp-2">{product.name}</h3>
                          <p className="text-slate-500 text-xs mb-auto">{product.category}</p>
                          <div className="mt-3 pt-3 border-t border-white/5 flex justify-between items-center">
                            <span className="text-white font-bold">₹{price.toLocaleString('en-IN')}</span>
                            {dp && dp.discount_pct > 0.5 && (
                              <span className="text-emerald-400 text-xs">-{Math.round(dp.discount_pct)}%</span>
                            )}
                          </div>
                        </a>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      <PerfMonitor wsLatency={wsLatency} onLowFPS={handleLowFPS} />
    </div>
  );
}

function getCategoryEmoji(category: string): string {
  const map: Record<string, string> = {
    Electronics: '💻', Audio: '🎧', Gaming: '🎮', Photography: '📷',
    Wearables: '⌚', 'Mobile Phones': '📱', Accessories: '🔌',
  };
  return map[category] ?? '📦';
}
