'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { usePersonaStore } from '@/store/personaStore';
import { getProduct, Product } from '@/lib/api';
import { useBehaviorTracker } from '@/hooks/useBehaviorTracker';
import Navbar from '@/components/Navbar';
import {
  ArrowLeft, CreditCard, ShieldCheck, Truck,
  ChevronDown, ChevronUp, Zap, Check, Lock
} from 'lucide-react';

const PERSONA_OFFERS: Record<string, { label: string; color: string; bg: string }> = {
  skimmer:    { label: '⚡ Flash checkout — 2-min express delivery scheduling', color: '#f97316', bg: '#fff4ec' },
  researcher: { label: '🔬 Premium buyer priority — dedicated customer support included', color: '#1a56db', bg: '#e8f3ff' },
  hunter:     { label: '🎯 Deal earned! Extra ₹200 off your total applied', color: '#2db88a', bg: '#e8f8f3' },
  unknown:    { label: '✨ New member bonus — Free express shipping on first order', color: '#7c3aed', bg: '#f3eeff' },
};

export default function CheckoutPage() {
  const router = useRouter();
  const { cartItems, priceMap, persona, placeOrder, addToast } = usePersonaStore();
  const { trackEvent } = useBehaviorTracker();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [placing, setPlacing] = useState(false);
  const [step, setStep] = useState<'details' | 'payment' | 'success'>('details');
  const [orderId, setOrderId] = useState('');
  const [showOrderSummary, setShowOrderSummary] = useState(true);

  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    pincode: '',
    state: '',
    cardNumber: '',
    expiry: '',
    cvv: '',
    cardName: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (cartItems.length === 0 && step !== 'success') {
      router.replace('/cart');
      return;
    }
    const load = async () => {
      const fetched = await Promise.all(
        cartItems.map((id) => getProduct(id).catch(() => null))
      );
      setProducts(fetched.filter(Boolean) as Product[]);
      setLoading(false);
    };
    load();
  }, [cartItems, router, step]);

  const total = products.reduce((sum, p) => {
    const price = priceMap[p.id]?.final_price ?? p.base_price;
    return sum + price;
  }, 0);

  const savings = products.reduce((sum, p) => {
    const dp = priceMap[p.id];
    if (dp && dp.discount_pct > 0.5) return sum + (p.base_price - dp.final_price);
    return sum;
  }, 0);

  const hunterBonus = persona === 'hunter' ? 200 : 0;
  const finalTotal = Math.max(0, Math.round(total) - hunterBonus);

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    if (!form.name.trim()) newErrors.name = 'Full name is required';
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) newErrors.email = 'Valid email required';
    if (!form.phone.match(/^[6-9]\d{9}$/)) newErrors.phone = 'Valid 10-digit Indian mobile number required';
    if (!form.address.trim()) newErrors.address = 'Address is required';
    if (!form.city.trim()) newErrors.city = 'City is required';
    if (!form.pincode.match(/^\d{6}$/)) newErrors.pincode = 'Valid 6-digit pincode required';
    if (!form.state.trim()) newErrors.state = 'State is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};
    const stripped = form.cardNumber.replace(/\s/g, '');
    if (!stripped.match(/^\d{16}$/)) newErrors.cardNumber = 'Valid 16-digit card number required';
    if (!form.expiry.match(/^(0[1-9]|1[0-2])\/\d{2}$/)) newErrors.expiry = 'Format: MM/YY';
    if (!form.cvv.match(/^\d{3,4}$/)) newErrors.cvv = 'Valid CVV required';
    if (!form.cardName.trim()) newErrors.cardName = 'Name on card required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinueToPayment = () => {
    if (validateStep1()) setStep('payment');
  };

  const handlePlaceOrder = async () => {
    if (!validateStep2()) return;
    setPlacing(true);
    // Simulate payment processing
    await new Promise((r) => setTimeout(r, 1800));

    const orderItems = products.map((p) => ({
      productId: p.id,
      name: p.name,
      price: priceMap[p.id]?.final_price ?? p.base_price,
      image: p.image,
    }));

    const id = placeOrder({
      items: orderItems,
      total: finalTotal,
      savings: savings + hunterBonus,
      persona,
    });

    setOrderId(id);
    setStep('success');
    setPlacing(false);
    addToast('🎉 Order placed successfully!', 'success');
    if (trackEvent) trackEvent('purchase');
  };

  const updateForm = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const formatCard = (value: string) =>
    value.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();

  const formatExpiry = (value: string) => {
    const clean = value.replace(/\D/g, '').slice(0, 4);
    return clean.length >= 2 ? `${clean.slice(0, 2)}/${clean.slice(2)}` : clean;
  };

  const offerConfig = PERSONA_OFFERS[persona] ?? PERSONA_OFFERS.unknown;

  if (step === 'success') {
    return (
      <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
        <Navbar />
        <main style={{ maxWidth: '600px', margin: '0 auto', padding: '4rem 1.5rem', textAlign: 'center' }}>
          {/* Success animation */}
          <div style={{
            width: 96, height: 96, borderRadius: '50%',
            background: 'linear-gradient(135deg, #059669, #34d399)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 2rem', boxShadow: '0 0 48px rgba(52,211,153,0.35)',
          }}>
            <Check size={48} color="white" strokeWidth={3} />
          </div>

          <h1 style={{ fontSize: '2rem', fontWeight: 900, color: 'var(--text-primary)', marginBottom: '0.5rem', letterSpacing: '-0.02em' }}>
            Order Confirmed! 🎉
          </h1>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>
            Thank you, {form.name.split(' ')[0]}! Your order has been placed successfully.
          </p>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '2.5rem' }}>
            Confirmation sent to <strong>{form.email}</strong>
          </p>

          <div className="card" style={{ padding: '1.5rem', marginBottom: '1.5rem', textAlign: 'left' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <span style={{ fontWeight: 700, color: 'var(--text-primary)' }}>Order ID</span>
              <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--accent)', fontSize: '1rem' }}>{orderId}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span style={{ color: 'var(--text-secondary)' }}>{products.length} item{products.length !== 1 ? 's' : ''}</span>
              <span style={{ fontWeight: 700, color: 'var(--text-primary)' }}>₹{finalTotal.toLocaleString('en-IN')}</span>
            </div>
            {savings + hunterBonus > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: '#2db88a' }}>AI Savings</span>
                <span style={{ fontWeight: 700, color: '#2db88a' }}>-₹{Math.round(savings + hunterBonus).toLocaleString('en-IN')}</span>
              </div>
            )}
            <div style={{ marginTop: '1rem', padding: '0.875rem', background: 'var(--surface-2)', borderRadius: 'var(--r-sm)' }}>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', fontWeight: 600 }}>
                📦 Estimated Delivery: <strong>{getDeliveryDate()}</strong>
              </p>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>
                Shipping to: {form.address}, {form.city} — {form.pincode}
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/products">
              <button className="btn-primary">Continue Shopping</button>
            </Link>
            <Link href="/dashboard">
              <button className="btn-outline">View Dashboard</button>
            </Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Navbar />
      <main style={{ maxWidth: '1100px', margin: '0 auto', padding: '2rem 1.5rem 5rem' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
          <Link href="/cart">
            <button className="btn-ghost" style={{ padding: '0.5rem 0.875rem' }}>
              <ArrowLeft size={16} /> Back to Cart
            </button>
          </Link>
          <h1 style={{ fontWeight: 900, fontSize: '1.5rem', color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
            Checkout
          </h1>
        </div>

        {/* Persona offer banner */}
        <div style={{
          background: offerConfig.bg, border: `1px solid ${offerConfig.color}30`,
          borderRadius: 'var(--r-md)', padding: '0.875rem 1.25rem',
          marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.75rem',
        }}>
          <Zap size={16} color={offerConfig.color} />
          <p style={{ fontSize: '0.85rem', fontWeight: 600, color: offerConfig.color }}>
            {offerConfig.label}
          </p>
        </div>

        {/* Step indicator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '2rem' }}>
          {[
            { num: 1, label: 'Delivery', done: step === 'payment' },
            { num: 2, label: 'Payment', done: false },
          ].map(({ num, label, done }, idx) => (
            <div key={num} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{
                width: 32, height: 32, borderRadius: '50%',
                background: done ? '#2db88a' : (step === (num === 1 ? 'details' : 'payment') ? 'var(--text-primary)' : 'var(--surface-2)'),
                color: done ? 'white' : (step === (num === 1 ? 'details' : 'payment') ? 'white' : 'var(--text-muted)'),
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 800, fontSize: '0.85rem',
              }}>
                {done ? <Check size={14} /> : num}
              </div>
              <span style={{
                fontWeight: 600, fontSize: '0.875rem',
                color: step === (num === 1 ? 'details' : 'payment') ? 'var(--text-primary)' : 'var(--text-muted)',
              }}>
                {label}
              </span>
              {idx === 0 && <div style={{ width: 40, height: 1, background: 'var(--border)' }} />}
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '1.5rem', alignItems: 'start' }}>
          {/* Main form */}
          <div className="card" style={{ padding: '1.75rem' }}>
            {step === 'details' && (
              <>
                <h2 style={{ fontWeight: 800, marginBottom: '1.5rem', fontSize: '1.05rem', color: 'var(--text-primary)' }}>
                  Delivery Details
                </h2>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  {renderInput('name', 'Full Name', form, updateForm, errors, 'text', { gridColumn: '1/-1' })}
                  {renderInput('email', 'Email Address', form, updateForm, errors, 'email', { gridColumn: '1/-1' })}
                  {renderInput('phone', 'Mobile Number', form, updateForm, errors, 'tel')}
                  <div />
                  {renderInput('address', 'Full Address', form, updateForm, errors, 'text', { gridColumn: '1/-1' })}
                  {renderInput('city', 'City', form, updateForm, errors)}
                  {renderInput('pincode', 'PIN Code', form, updateForm, errors)}
                  {renderInput('state', 'State', form, updateForm, errors, 'text', { gridColumn: '1/-1' })}
                </div>
                <button
                  onClick={handleContinueToPayment}
                  className="btn-primary"
                  style={{ marginTop: '1.5rem', width: '100%', justifyContent: 'center', padding: '1rem' }}
                >
                  Continue to Payment <ChevronDown size={16} />
                </button>
              </>
            )}

            {step === 'payment' && (
              <>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
                  <h2 style={{ fontWeight: 800, fontSize: '1.05rem', color: 'var(--text-primary)' }}>
                    Payment Details
                  </h2>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.375rem', fontSize: '0.72rem', fontWeight: 700, color: 'var(--mint)' }}>
                    <Lock size={12} /> SSL Secured
                  </div>
                </div>

                {/* Card preview */}
                <div style={{
                  background: 'linear-gradient(135deg, var(--text-primary) 0%, #1e293b 100%)',
                  borderRadius: 'var(--r-lg)', padding: '1.5rem', marginBottom: '1.5rem',
                  position: 'relative', overflow: 'hidden',
                  boxShadow: '0 8px 32px rgba(13,17,23,0.2)',
                }}>
                  <div style={{
                    position: 'absolute', top: -30, right: -30, width: 160, height: 160,
                    borderRadius: '50%', background: 'rgba(255,255,255,0.04)',
                  }} />
                  <div style={{
                    position: 'absolute', bottom: -20, left: -20, width: 120, height: 120,
                    borderRadius: '50%', background: 'rgba(255,255,255,0.03)',
                  }} />
                  <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '1.5rem' }}>
                    Credit / Debit Card
                  </p>
                  <p style={{ color: 'white', fontSize: '1.15rem', fontFamily: 'monospace', letterSpacing: '0.15em', marginBottom: '1.5rem', fontWeight: 600 }}>
                    {form.cardNumber || '•••• •••• •••• ••••'}
                  </p>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <div>
                      <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.6rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Card Holder</p>
                      <p style={{ color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>{form.cardName || 'YOUR NAME'}</p>
                    </div>
                    <div>
                      <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.6rem', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Expires</p>
                      <p style={{ color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>{form.expiry || 'MM/YY'}</p>
                    </div>
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div style={{ gridColumn: '1/-1' }}>
                    {renderInput('cardNumber', 'Card Number', form, (f, v) => updateForm(f, formatCard(v)), errors, 'text')}
                  </div>
                  {renderInput('cardName', 'Name on Card', form, updateForm, errors, 'text', { gridColumn: '1/-1' })}
                  {renderInput('expiry', 'Expiry (MM/YY)', form, (f, v) => updateForm(f, formatExpiry(v)), errors)}
                  {renderInput('cvv', 'CVV', form, updateForm, errors, 'password')}
                </div>

                <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem' }}>
                  <button
                    onClick={() => setStep('details')}
                    className="btn-ghost"
                    style={{ padding: '1rem 1.5rem' }}
                  >
                    <ChevronUp size={16} /> Back
                  </button>
                  <button
                    onClick={handlePlaceOrder}
                    disabled={placing}
                    className="btn-primary"
                    style={{ flex: 1, justifyContent: 'center', padding: '1rem', opacity: placing ? 0.7 : 1 }}
                  >
                    {placing ? (
                      <>
                        <div style={{ width: 16, height: 16, border: '2px solid white', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                        Processing…
                      </>
                    ) : (
                      <><CreditCard size={16} /> Pay ₹{finalTotal.toLocaleString('en-IN')}</>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Order Summary sidebar */}
          <div style={{ position: 'sticky', top: '80px' }}>
            <div className="card" style={{ padding: '1.25rem', marginBottom: '1rem' }}>
              <button
                onClick={() => setShowOrderSummary(!showOrderSummary)}
                style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
              >
                <h3 style={{ fontWeight: 800, fontSize: '0.925rem', color: 'var(--text-primary)' }}>
                  Order Summary ({cartItems.length})
                </h3>
                {showOrderSummary ? <ChevronUp size={16} color="var(--text-muted)" /> : <ChevronDown size={16} color="var(--text-muted)" />}
              </button>

              {showOrderSummary && (
                <div style={{ marginTop: '1rem' }}>
                  {products.map((p) => {
                    const price = priceMap[p.id]?.final_price ?? p.base_price;
                    return (
                      <div key={p.id} style={{ display: 'flex', gap: '0.75rem', marginBottom: '0.875rem', alignItems: 'center' }}>
                        <div style={{ width: 44, height: 44, borderRadius: 'var(--r-sm)', overflow: 'hidden', background: 'var(--surface-2)', flexShrink: 0 }}>
                          {p.image && <img src={p.image} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} referrerPolicy="no-referrer-when-downgrade" />}
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <p style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</p>
                          <p style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>{p.category}</p>
                        </div>
                        <p style={{ fontWeight: 800, fontSize: '0.875rem', color: 'var(--text-primary)', flexShrink: 0 }}>₹{Math.round(price).toLocaleString('en-IN')}</p>
                      </div>
                    );
                  })}
                </div>
              )}

              <div style={{ borderTop: '1px solid var(--border-light)', paddingTop: '1rem', marginTop: '0.5rem' }}>
                {savings > 0.5 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                    <span style={{ fontSize: '0.825rem', color: '#2db88a' }}>AI Savings</span>
                    <span style={{ fontWeight: 700, color: '#2db88a', fontSize: '0.825rem' }}>-₹{Math.round(savings).toLocaleString('en-IN')}</span>
                  </div>
                )}
                {hunterBonus > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                    <span style={{ fontSize: '0.825rem', color: '#2db88a' }}>🎯 Hunter Bonus</span>
                    <span style={{ fontWeight: 700, color: '#2db88a', fontSize: '0.825rem' }}>-₹{hunterBonus}</span>
                  </div>
                )}
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <span style={{ fontSize: '0.825rem', color: 'var(--text-secondary)' }}>Shipping</span>
                  <span style={{ fontWeight: 700, color: '#2db88a', fontSize: '0.825rem' }}>Free</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: '0.75rem', borderTop: '1px solid var(--border-light)', marginTop: '0.5rem' }}>
                  <span style={{ fontWeight: 800, color: 'var(--text-primary)' }}>Total</span>
                  <span style={{ fontWeight: 900, fontSize: '1.15rem', color: 'var(--text-primary)' }}>₹{finalTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>

            {/* Trust badges */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {[
                { icon: <ShieldCheck size={14} />, text: '256-bit SSL encrypted payments' },
                { icon: <Truck size={14} />, text: 'Free delivery on all orders' },
                { icon: <Check size={14} />, text: '30-day free returns' },
              ].map(({ icon, text }) => (
                <div key={text} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>
                  <span style={{ color: 'var(--mint)' }}>{icon}</span>
                  {text}
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <style jsx global>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}

function renderInput(
  field: string,
  label: string,
  form: Record<string, string>,
  updateForm: (f: string, v: string) => void,
  errors: Record<string, string>,
  type = 'text',
  style: React.CSSProperties = {}
) {
  return (
    <div key={field} style={style}>
      <label style={{ display: 'block', fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-muted)', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: '0.375rem' }}>
        {label}
      </label>
      <input
        type={type}
        value={form[field] || ''}
        onChange={(e) => updateForm(field, e.target.value)}
        className="input-base"
        style={{
          borderRadius: 'var(--r-sm)',
          padding: '0.75rem 1rem',
          borderColor: errors[field] ? '#e11d48' : undefined,
        }}
        placeholder={label}
      />
      {errors[field] && (
        <p style={{ fontSize: '0.68rem', color: '#e11d48', marginTop: '0.25rem', fontWeight: 600 }}>{errors[field]}</p>
      )}
    </div>
  );
}

function getDeliveryDate(): string {
  const d = new Date();
  d.setDate(d.getDate() + 3);
  return d.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });
}
