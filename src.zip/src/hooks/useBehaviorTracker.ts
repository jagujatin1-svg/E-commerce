'use client';

/**
 * useBehaviorTracker — passive event capture hook.
 * Automatically tracks: page views, clicks, scrolls, hovers (on products),
 * and firing them to the backend /events endpoint.
 * Attaches to the document so no manual integration needed per component.
 */
import { useEffect, useRef, useCallback } from 'react';
import { sendEvent, BehaviorEvent } from '@/lib/api';
import { getSessionId } from '@/lib/sessionId';

interface TrackerOptions {
  category?: string;
  productId?: string;
}

export function useBehaviorTracker(options: TrackerOptions = {}) {
  const sessionId = getSessionId();
  const hoverStart = useRef<number>(0);
  const scrollTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastScrollY = useRef<number>(0);
  const pageViewSent = useRef(false);

  const fire = useCallback((event: Omit<BehaviorEvent, 'session_id'>) => {
    sendEvent({ ...event, session_id: sessionId });
  }, [sessionId]);

  // ── Page view ──────────────────────────────────────────────
  useEffect(() => {
    if (!pageViewSent.current) {
      pageViewSent.current = true;
      fire({
        event_type: 'page_view',
        product_id: options.productId,
        category: options.category,
        metadata: { url: window.location.pathname },
      });
    }
  }, [fire, options.productId, options.category]);

  // ── Click tracking ─────────────────────────────────────────
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      const el = e.target as HTMLElement;
      const productCard = el.closest('[data-product-id]') as HTMLElement | null;
      const category = el.closest('[data-category]')?.getAttribute('data-category') ?? options.category;
      fire({
        event_type: 'click',
        product_id: productCard?.getAttribute('data-product-id') ?? options.productId,
        category,
        metadata: { tag: el.tagName, class: (el.className?.toString?.() || '').slice(0, 50) },
      });
    };
    document.addEventListener('click', onClick);
    return () => document.removeEventListener('click', onClick);
  }, [fire, options.productId, options.category]);

  // ── Scroll tracking ────────────────────────────────────────
  useEffect(() => {
    const onScroll = () => {
      const currentY = window.scrollY;
      const delta = Math.abs(currentY - lastScrollY.current);
      lastScrollY.current = currentY;

      if (scrollTimer.current) clearTimeout(scrollTimer.current);
      scrollTimer.current = setTimeout(() => {
        fire({
          event_type: 'scroll',
          category: options.category,
          metadata: {
            scroll_y: currentY,
            speed: Math.round(delta),
            direction: currentY > lastScrollY.current ? 'down' : 'up',
          },
        });
      }, 300);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [fire, options.category]);

  // ── Hover tracking on product cards ───────────────────────
  useEffect(() => {
    const onMouseEnter = (e: MouseEvent) => {
      const el = e.target as HTMLElement;
      if (el.closest('[data-product-id]')) {
        hoverStart.current = Date.now();
      }
    };
    const onMouseLeave = (e: MouseEvent) => {
      const el = e.target as HTMLElement;
      const card = el.closest('[data-product-id]') as HTMLElement | null;
      if (card && hoverStart.current > 0) {
        const duration = Date.now() - hoverStart.current;
        if (duration > 200) { // Only fire if hover > 200ms
          fire({
            event_type: 'hover',
            product_id: card.getAttribute('data-product-id') ?? undefined,
            category: card.getAttribute('data-category') ?? options.category,
            metadata: { duration_ms: duration },
          });
        }
        hoverStart.current = 0;
      }
    };
    document.addEventListener('mouseenter', onMouseEnter, true);
    document.addEventListener('mouseleave', onMouseLeave, true);
    return () => {
      document.removeEventListener('mouseenter', onMouseEnter, true);
      document.removeEventListener('mouseleave', onMouseLeave, true);
    };
  }, [fire, options.category]);

  // ── Manual event helpers ───────────────────────────────────
  const trackSearch = useCallback((query: string) => {
    fire({ event_type: 'search', metadata: { query }, category: options.category });
  }, [fire, options.category]);

  const trackCartAdd = useCallback((productId: string, category?: string) => {
    fire({ event_type: 'cart_add', product_id: productId, category });
  }, [fire]);

  const trackCartRemove = useCallback((productId: string) => {
    fire({ event_type: 'cart_remove', product_id: productId });
  }, [fire]);

  const trackEvent = useCallback((eventType: BehaviorEvent['event_type'], productId?: string, category?: string) => {
    fire({ event_type: eventType, product_id: productId, category });
  }, [fire]);

  return { sessionId, trackSearch, trackCartAdd, trackCartRemove, trackEvent };
}
