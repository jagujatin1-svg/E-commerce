'use client';

/**
 * useWebSocket — Connects to backend WS and pipes updates to Zustand store.
 * - Initial connection delayed 500ms to let the page settle.
 * - Exponential backoff: 2s → 4s → 8s → ... → 30s max.
 * - Console noise suppressed after first connect attempt.
 * - Keep-alive ping every 25s.
 */
import { useEffect, useRef } from 'react';
import { usePersonaStore } from '@/store/personaStore';

const WS_BASE = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8000';

export function useWebSocket(sessionId: string) {
  const ws = useRef<WebSocket | null>(null);
  const reconnectDelay = useRef(2000);   // Start at 2s, not 1s
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const attemptCount = useRef(0);
  const mounted = useRef(true);
  const { updatePersona, updatePrice, setConnected } = usePersonaStore();

  useEffect(() => {
    if (!sessionId) return;
    mounted.current = true;

    const connect = () => {
      if (!mounted.current) return;

      // Close existing socket before opening a new one
      if (ws.current && ws.current.readyState !== WebSocket.CLOSED) {
        ws.current.close();
      }

      const socket = new WebSocket(`${WS_BASE}/ws/${sessionId}`);
      ws.current = socket;
      attemptCount.current += 1;

      socket.onopen = () => {
        if (!mounted.current) return;
        setConnected(true);
        reconnectDelay.current = 2000;  // Reset backoff on success
        attemptCount.current = 0;
        console.log('🔌 WebSocket connected');
      };

      socket.onmessage = (event) => {
        if (!mounted.current) return;
        try {
          const data = JSON.parse(event.data);

          if (data.type === 'persona_update' || data.type === 'connected') {
            updatePersona({
              persona: data.persona,
              confidence: data.confidence ?? 0,
              scores: data.scores ?? { skimmer: 0, researcher: 0, hunter: 0 },
              signals: data.signals ?? [],
              uiMode: data.ui_mode ?? 'default',
              features: data.features ?? undefined,
            });
          }

          if (data.type === 'price_update' && data.price) {
            updatePrice(data.price);
          }
        } catch {
          // Malformed message — ignore
        }
      };

      socket.onclose = (event) => {
        if (!mounted.current) return;
        setConnected(false);

        // Only log after first silent attempt
        if (attemptCount.current > 1) {
          console.debug(`WS disconnected (code ${event.code}), retry in ${reconnectDelay.current / 1000}s`);
        }

        reconnectTimer.current = setTimeout(() => {
          reconnectDelay.current = Math.min(reconnectDelay.current * 2, 30000);
          connect();
        }, reconnectDelay.current);
      };

      socket.onerror = () => {
        // onerror is always followed by onclose — let onclose handle reconnects
        if (socket.readyState !== WebSocket.CLOSED) {
          socket.close();
        }
      };
    };

    // Small initial delay so Next.js hydration completes first
    const initTimer = setTimeout(connect, 500);

    // Keep-alive ping every 25s
    const pingInterval = setInterval(() => {
      if (ws.current?.readyState === WebSocket.OPEN) {
        ws.current.send('ping');
      }
    }, 25000);

    return () => {
      mounted.current = false;
      clearTimeout(initTimer);
      clearInterval(pingInterval);
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      ws.current?.close();
    };
  }, [sessionId, updatePersona, updatePrice, setConnected]);

  return ws;
}
