/**
 * Persona Zustand store — single source of truth for all real-time state.
 * Updated via WebSocket messages from the backend.
 */
import { create } from 'zustand';

export type PersonaType = 'skimmer' | 'researcher' | 'hunter' | 'unknown';
export type UIMode = 'trending' | 'detailed' | 'deals' | 'default';

export interface PersonaScores {
  skimmer: number;
  researcher: number;
  hunter: number;
}

export interface BehaviorFeatures {
  total_events: number;
  engagement_score: number;
  purchase_intent: number;
  avg_hover_duration: number;
  events_per_minute: number;
}

export interface DynamicPrice {
  product_id: string;
  base_price: number;
  final_price: number;
  discount_pct: number;
  multiplier: number;
  reasons: string[];
  persona_modifier?: number;
  demand_modifier?: number;
  inventory_modifier?: number;
}

export interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  image?: string;
}

export interface Order {
  id: string;
  items: OrderItem[];
  total: number;
  savings: number;
  placedAt: number;
  persona: PersonaType;
}

export interface PersonaState {
  sessionId: string;
  persona: PersonaType;
  confidence: number;
  scores: PersonaScores;
  signals: string[];
  uiMode: UIMode;
  features: BehaviorFeatures;
  isConnected: boolean;
  lastUpdated: number;
  priceMap: Record<string, DynamicPrice>;
  cartItems: string[];
  wishlistItems: string[];
  orders: Order[];
  toasts: ToastMessage[];
  // Actions
  setSessionId: (id: string) => void;
  updatePersona: (data: Partial<PersonaState>) => void;
  updatePrice: (price: DynamicPrice) => void;
  setConnected: (v: boolean) => void;
  addToCart: (productId: string) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  placeOrder: (order: Omit<Order, 'id' | 'placedAt'>) => string;
  addToast: (message: string, type?: ToastMessage['type']) => void;
  removeToast: (id: string) => void;
}

export const usePersonaStore = create<PersonaState>((set, get) => ({
  sessionId: '',
  persona: 'unknown',
  confidence: 0,
  scores: { skimmer: 0, researcher: 0, hunter: 0 },
  signals: ['👋 Building your profile...'],
  uiMode: 'default',
  features: {
    total_events: 0,
    engagement_score: 0,
    purchase_intent: 0,
    avg_hover_duration: 0,
    events_per_minute: 0,
  },
  isConnected: false,
  lastUpdated: 0,
  priceMap: {},
  cartItems: [],
  wishlistItems: [],
  orders: [],
  toasts: [],

  setSessionId: (id) => set({ sessionId: id }),

  updatePersona: (data) =>
    set((state) => ({
      ...state,
      ...data,
      lastUpdated: Date.now(),
    })),

  updatePrice: (price) =>
    set((state) => ({
      priceMap: { ...state.priceMap, [price.product_id]: price },
    })),

  setConnected: (v) => set({ isConnected: v }),

  addToCart: (productId) =>
    set((state) => ({
      cartItems: state.cartItems.includes(productId)
        ? state.cartItems
        : [...state.cartItems, productId],
    })),

  removeFromCart: (productId) =>
    set((state) => ({
      cartItems: state.cartItems.filter((id) => id !== productId),
    })),

  clearCart: () => set({ cartItems: [] }),

  toggleWishlist: (productId) =>
    set((state) => ({
      wishlistItems: state.wishlistItems.includes(productId)
        ? state.wishlistItems.filter((id) => id !== productId)
        : [...state.wishlistItems, productId],
    })),

  isWishlisted: (productId) => get().wishlistItems.includes(productId),

  placeOrder: (order) => {
    const id = `ORD-${Date.now().toString(36).toUpperCase()}`;
    set((state) => ({
      orders: [{ ...order, id, placedAt: Date.now() }, ...state.orders],
      cartItems: [],
    }));
    return id;
  },

  addToast: (message, type = 'success') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    set((state) => ({
      toasts: [...state.toasts, { id, message, type }],
    }));
    setTimeout(() => {
      set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
    }, 3500);
  },

  removeToast: (id) =>
    set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),
}));
